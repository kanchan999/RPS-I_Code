# Code for TENSION/COMPRESSION SPRING DESIGN (Table 12)
# Paper title: Regenerative Population Strategy-I: A Dynamic Methodology to Mitigate
#              Structural Bias in Metaheuristic Algorithms)
# Author: Kanchan Rajwar
# For assistance, contact: kanchanrajwar1519@gmail.com
#=======================================================================================================================
#=======================================================================================================================
import numpy as np

#=====================================================================
#  TENSION/COMPRESSION SPRING DESIGN (Objective + Constraints)
#=====================================================================
P = 500  #pop_size      #Set accoridng to your choice
I = 2000 #max_gens      #Set accoridng to your choice

def spring_objective(x):
    """
    Original objective: f(x) = (x3 + 2) * x2 * (x1^3).
    x = [x1, x2, x3].
    """
    x1, x2, x3 = x
    return (x3 + 2) * x2 * (x1**3)

def spring_constraints(x):
    """
    g1(x) = 1 - (x2^3*x3)/(71785*x1^4) <= 0
    g2(x) = (4*x2^2 - x1*x2)/(12566*(x2*x1^3 - x1^4)) + 1/(510*x1^2) - 1 <= 0
    g3(x) = 1 - (140.45*x1)/(x2^2*x3) <= 0
    g4(x) = (x1 + x2)/1.5 - 1 <= 0
    """
    x1, x2, x3 = x
    g1 = 1.0 - (x2**3 * x3) / (71785.0 * x1**4)
    denom = (x2 * x1**3 - x1**4)
    # Safeguard if denom is 0 or extremely small:
    if abs(denom) < 1e-12:
        # Highly infeasible => large positive violation
        g2 = 1e6
    else:
        g2 = ((4.0 * x2**2 - x1 * x2) / (12566.0 * denom)) + (1.0 / (510.0 * x1**2)) - 1.0
    g3 = 1.0 - (140.45 * x1) / (x2**2 * x3)
    g4 = ((x1 + x2) / 1.5) - 1.0
    return [g1, g2, g3, g4]

def spring_penalized_fitness(x, penalty_factor=1e6):
    """
    Evaluate the penalized fitness = objective + penalty_factor * sum_of_violations
    where violation = max(0, g_i(x)).
    """
    f = spring_objective(x)
    g_vals = spring_constraints(x)
    violation_sum = 0.0
    for g in g_vals:
        if g > 0.0:
            violation_sum += g
    return f + penalty_factor*violation_sum

# Bounds
lower_bounds = np.array([0.05, 0.25, 2.0])
upper_bounds = np.array([2.0, 1.3, 15.0])

# Utility: Clip an individual x to the feasible search bounds
def clip_to_bounds(x):
    return np.clip(x, lower_bounds, upper_bounds)

#=====================================================================
# 2) RPS-I Helper Functions (Diversity, Improvement rate, Combined γ)
#=====================================================================
def calculate_diversity(population):
    """
    population: shape (pop_size, 3), the current solutions.
    Diversity (alpha) = sum of Euclidean distances from mean.
    """
    mean_pos = np.mean(population, axis=0)
    return np.sum(np.linalg.norm(population - mean_pos, axis=1))

def calculate_improvement_rate(prev_best, curr_best):
    """
    Improvement rate (beta) = (prev_best - curr_best)/(curr_best+1e-9).
    """
    return (prev_best - curr_best) / (curr_best + 1e-9)

def update_rps_i(population, fitnesses, alpha_max, beta_max, prev_best_f, w_alpha=0.5, w_beta=0.5):
    """
    1) Compute alpha (diversity) and beta (improvement).
    2) gamma = w_alpha*(alpha/alpha_max) + w_beta*(beta/beta_max).
    3) Reinitialize a fraction (1 - gamma) of individuals, excluding best.
    Returns updated population, updated alpha_max/beta_max, new best reference.
    """
    pop_size = len(population)
    best_idx = np.argmin(fitnesses)
    best_f   = fitnesses[best_idx]

    alpha = calculate_diversity(population)
    alpha_max = max(alpha_max, alpha)

    beta = calculate_improvement_rate(prev_best_f, best_f)
    beta_max = max(beta_max, beta)

    gamma = w_alpha*(alpha/alpha_max) + w_beta*(beta/beta_max)
    gamma = np.clip(gamma, 0.0, 1.0)

    num_to_regen = int(np.floor((1.0 - gamma)*(pop_size - 1)))
    if num_to_regen > 0:
        # Exclude the best
        indices = np.arange(pop_size)
        indices = np.delete(indices, best_idx)
        if len(indices) > 0:
            regen_indices = np.random.choice(indices, size=min(num_to_regen, len(indices)), replace=False)
            for idx in regen_indices:
                # Reinitialize random
                rnd = np.random.rand(3)
                # Scale to bounds
                new_x = lower_bounds + rnd*(upper_bounds - lower_bounds)
                population[idx] = new_x
                # Evaluate new penalized fitness
                fitnesses[idx] = spring_penalized_fitness(new_x)

    return population, fitnesses, alpha_max, beta_max, min(best_f, prev_best_f)

#=====================================================================
# 3) GENETIC ALGORITHM (GA) and RPS-I-GA
#=====================================================================
def ga_spring(pop_size=P, max_gens=I):
    """
    Standard GA with:
      - Real-coded
      - Roulette-wheel selection
      - Single-point crossover (prob=1)
      - Mutation rate=0.01
    """
    crossover_rate = 1.0
    mutation_rate  = 0.01

    # Initialize population
    population = []
    for _ in range(pop_size):
        rnd = np.random.rand(3)
        x   = lower_bounds + rnd*(upper_bounds - lower_bounds)
        population.append(x)
    population = np.array(population)
    fitnesses  = np.array([spring_penalized_fitness(ind) for ind in population])

    def roulette_wheel_selection(pop, fits):
        # Minimizing, so define fitness ~ 1/(1+ cost) or something similar
        # Or we can do "fitness = 1 - (cost / max_cost+epsilon)" but let's do a simpler approach:
        # We can invert large cost => small fitness. For demonstration, we'll do:
        #   raw_fit = 1.0/(1.0 + fits).
        raw_fit = 1.0/(1.0 + fits)
        total = np.sum(raw_fit)
        if total < 1e-12:
            # fallback random
            indices = np.random.randint(0, len(pop), size=len(pop))
            return pop[indices]
        cdf = np.cumsum(raw_fit / total)
        new_pop = []
        for _ in range(len(pop)):
            r = np.random.rand()
            idx = np.searchsorted(cdf, r)
            new_pop.append(pop[idx])
        return np.array(new_pop)

    def single_point_crossover(parent1, parent2):
        # We choose one dimension out of 3
        cp = np.random.randint(1, 3)  # possible cross at dimension=1 or 2
        c1 = np.concatenate([parent1[:cp], parent2[cp:]])
        c2 = np.concatenate([parent2[:cp], parent1[cp:]])
        return c1, c2

    def mutate(offspring):
        # Mutate each dimension with probability=mutation_rate
        for d in range(3):
            if np.random.rand() < mutation_rate:
                # random in [lb, ub]
                lb, ub = lower_bounds[d], upper_bounds[d]
                offspring[d] = lb + (ub - lb)*np.random.rand()
        return offspring

    for gen in range(max_gens):
        # Selection
        mating_pool = roulette_wheel_selection(population, fitnesses)

        # Recombine
        new_population = []
        for i in range(0, pop_size, 2):
            p1 = mating_pool[i]
            p2 = mating_pool[i] if (i+1==pop_size) else mating_pool[i+1]
            if np.random.rand() < crossover_rate:
                c1, c2 = single_point_crossover(p1, p2)
            else:
                c1, c2 = np.copy(p1), np.copy(p2)
            c1 = mutate(c1)
            c2 = mutate(c2)
            c1 = clip_to_bounds(c1)
            c2 = clip_to_bounds(c2)
            new_population.append(c1)
            new_population.append(c2)
        population = np.array(new_population)[:pop_size]

        # Evaluate
        fitnesses = np.array([spring_penalized_fitness(ind) for ind in population])

    best_idx = np.argmin(fitnesses)
    return population[best_idx], fitnesses[best_idx]

def rps_i_ga_spring(pop_size=P, max_gens=I):
    """
    GA with RPS-I mechanism at each generation.
    """
    # same GA params
    crossover_rate = 1.0
    mutation_rate  = 0.01

    # init population
    population = []
    for _ in range(pop_size):
        rnd = np.random.rand(3)
        x   = lower_bounds + rnd*(upper_bounds - lower_bounds)
        population.append(x)
    population = np.array(population)
    fitnesses  = np.array([spring_penalized_fitness(ind) for ind in population])

    # for RPS-I
    alpha_max = 1e-6
    beta_max  = 1e-6
    best_idx  = np.argmin(fitnesses)
    prev_best = fitnesses[best_idx]

    # GA helpers
    def roulette_wheel_selection(pop, fits):
        raw_fit = 1.0/(1.0 + fits)
        total = np.sum(raw_fit)
        if total < 1e-12:
            indices = np.random.randint(0, len(pop), size=len(pop))
            return pop[indices]
        cdf = np.cumsum(raw_fit / total)
        new_pop = []
        for _ in range(len(pop)):
            r = np.random.rand()
            idx = np.searchsorted(cdf, r)
            new_pop.append(pop[idx])
        return np.array(new_pop)

    def single_point_crossover(parent1, parent2):
        cp = np.random.randint(1, 3)
        c1 = np.concatenate([parent1[:cp], parent2[cp:]])
        c2 = np.concatenate([parent2[:cp], parent1[cp:]])
        return c1, c2

    def mutate(offspring):
        for d in range(3):
            if np.random.rand() < mutation_rate:
                lb, ub = lower_bounds[d], upper_bounds[d]
                offspring[d] = lb + (ub - lb)*np.random.rand()
        return offspring

    for gen in range(max_gens):
        # 1) RPS-I
        population, fitnesses, alpha_max, beta_max, prev_best = update_rps_i(
            population, fitnesses, alpha_max, beta_max, prev_best
        )
        # 2) Standard GA
        mating_pool = roulette_wheel_selection(population, fitnesses)
        new_population = []
        for i in range(0, pop_size, 2):
            p1 = mating_pool[i]
            p2 = mating_pool[i] if (i+1==pop_size) else mating_pool[i+1]
            if np.random.rand() < crossover_rate:
                c1, c2 = single_point_crossover(p1, p2)
            else:
                c1, c2 = np.copy(p1), np.copy(p2)
            c1 = mutate(c1)
            c2 = mutate(c2)
            c1 = clip_to_bounds(c1)
            c2 = clip_to_bounds(c2)
            new_population.append(c1)
            new_population.append(c2)
        population = np.array(new_population)[:pop_size]
        fitnesses  = np.array([spring_penalized_fitness(ind) for ind in population])

    best_idx = np.argmin(fitnesses)
    return population[best_idx], fitnesses[best_idx]


#=====================================================================
# 4) PSO and RPS-I-PSO
#=====================================================================
def pso_spring(pop_size=P, max_gens=I):
    w_max, w_min = 0.9, 0.1
    c1, c2       = 2.0, 2.0
    # Initialize
    positions = lower_bounds + np.random.rand(pop_size,3)*(upper_bounds - lower_bounds)
    velocities= 0.1 * (np.random.rand(pop_size,3)*2.0 -1.0)
    personal_best_pos = np.copy(positions)
    personal_best_fit = np.array([spring_penalized_fitness(x) for x in positions])
    global_best_idx   = np.argmin(personal_best_fit)
    global_best_pos   = personal_best_pos[global_best_idx].copy()
    global_best_fit   = personal_best_fit[global_best_idx]

    for gen in range(max_gens):
        w_t = w_max - (w_max - w_min)*gen/(max_gens - 1)
        for i in range(pop_size):
            fit_i = spring_penalized_fitness(positions[i])
            if fit_i < personal_best_fit[i]:
                personal_best_fit[i] = fit_i
                personal_best_pos[i] = positions[i].copy()
            if fit_i < global_best_fit:
                global_best_fit = fit_i
                global_best_pos = positions[i].copy()
        # Update velocities and positions
        for i in range(pop_size):
            r1, r2 = np.random.rand(3), np.random.rand(3)
            cognitive = c1*r1*(personal_best_pos[i] - positions[i])
            social    = c2*r2*(global_best_pos - positions[i])
            velocities[i] = w_t*velocities[i] + cognitive + social
            positions[i] += velocities[i]
            positions[i] = clip_to_bounds(positions[i])

    return global_best_pos, global_best_fit

def rps_i_pso_spring(pop_size=P, max_gens=I):
    w_max, w_min = 0.9, 0.1
    c1, c2       = 2.0, 2.0
    # Initialize
    positions = lower_bounds + np.random.rand(pop_size,3)*(upper_bounds - lower_bounds)
    velocities= 0.1 * (np.random.rand(pop_size,3)*2.0 -1.0)
    personal_best_pos = np.copy(positions)
    personal_best_fit = np.array([spring_penalized_fitness(x) for x in positions])
    global_best_idx   = np.argmin(personal_best_fit)
    global_best_pos   = personal_best_pos[global_best_idx].copy()
    global_best_fit   = personal_best_fit[global_best_idx]

    # RPS-I
    alpha_max, beta_max = 1e-6, 1e-6
    prev_best = global_best_fit

    for gen in range(max_gens):
        # RPS-I step
        pop_fit = np.array([spring_penalized_fitness(x) for x in positions])
        positions, pop_fit, alpha_max, beta_max, prev_best = update_rps_i(
            positions, pop_fit, alpha_max, beta_max, prev_best
        )
        # Reassign
        for i in range(pop_size):
            velocities[i] = 0.1*(np.random.rand(3)*2.0 -1.0)  # optional: reset velocities of reinit individuals
        # Evaluate after reinit
        for i in range(pop_size):
            personal_fit_i = spring_penalized_fitness(positions[i])
            if personal_fit_i < personal_best_fit[i]:
                personal_best_fit[i] = personal_fit_i
                personal_best_pos[i] = positions[i].copy()
        global_best_idx = np.argmin(personal_best_fit)
        global_best_fit = personal_best_fit[global_best_idx]
        global_best_pos = personal_best_pos[global_best_idx].copy()

        # Then do standard PSO velocity/position update
        w_t = w_max - (w_max - w_min)*gen/(max_gens - 1)
        for i in range(pop_size):
            r1, r2 = np.random.rand(3), np.random.rand(3)
            cognitive = c1*r1*(personal_best_pos[i] - positions[i])
            social    = c2*r2*(global_best_pos - positions[i])
            velocities[i] = w_t*velocities[i] + cognitive + social
            positions[i] += velocities[i]
            positions[i] = clip_to_bounds(positions[i])
            # Update personal/global best
            fit_i = spring_penalized_fitness(positions[i])
            if fit_i < personal_best_fit[i]:
                personal_best_fit[i] = fit_i
                personal_best_pos[i] = positions[i].copy()
            if fit_i < global_best_fit:
                global_best_fit = fit_i
                global_best_pos = positions[i].copy()

    return global_best_pos, global_best_fit

#=====================================================================
# 5) DIFFERENTIAL EVOLUTION (DE) and RPS-I-DE
#=====================================================================
def de_spring(pop_size=P, max_gens=I, F=0.5, CR=0.5):
    # Initialize
    population = lower_bounds + np.random.rand(pop_size,3)*(upper_bounds - lower_bounds)
    fitnesses  = np.array([spring_penalized_fitness(x) for x in population])

    for gen in range(max_gens):
        for i in range(pop_size):
            # pick r1,r2,r3 distinct from i
            idxs = [idx for idx in range(pop_size) if idx!=i]
            r1, r2, r3 = np.random.choice(idxs, 3, replace=False)
            donor = population[r1] + F*(population[r2]-population[r3])
            donor = clip_to_bounds(donor)
            # binomial crossover
            trial = np.copy(population[i])
            rand_dim = np.random.randint(3)
            for d in range(3):
                if np.random.rand() < CR or d==rand_dim:
                    trial[d] = donor[d]
            trial = clip_to_bounds(trial)
            trial_fit = spring_penalized_fitness(trial)
            # selection
            if trial_fit < fitnesses[i]:
                population[i] = trial
                fitnesses[i]  = trial_fit

    best_idx = np.argmin(fitnesses)
    return population[best_idx], fitnesses[best_idx]

def rps_i_de_spring(pop_size=P, max_gens=I, F=0.5, CR=0.5):
    population = lower_bounds + np.random.rand(pop_size,3)*(upper_bounds - lower_bounds)
    fitnesses  = np.array([spring_penalized_fitness(x) for x in population])

    # RPS-I
    alpha_max, beta_max = 1e-6, 1e-6
    best_idx  = np.argmin(fitnesses)
    prev_best = fitnesses[best_idx]

    for gen in range(max_gens):
        # RPS-I
        population, fitnesses, alpha_max, beta_max, prev_best = update_rps_i(
            population, fitnesses, alpha_max, beta_max, prev_best
        )
        # DE iteration
        for i in range(pop_size):
            idxs = [idx for idx in range(pop_size) if idx!=i]
            r1, r2, r3 = np.random.choice(idxs, 3, replace=False)
            donor = population[r1] + F*(population[r2] - population[r3])
            donor = clip_to_bounds(donor)
            trial = np.copy(population[i])
            rand_dim = np.random.randint(3)
            for d in range(3):
                if np.random.rand() < CR or d==rand_dim:
                    trial[d] = donor[d]
            trial = clip_to_bounds(trial)
            t_fit = spring_penalized_fitness(trial)
            if t_fit < fitnesses[i]:
                population[i] = trial
                fitnesses[i]  = t_fit

    best_idx = np.argmin(fitnesses)
    return population[best_idx], fitnesses[best_idx]


#=====================================================================
# 6) GREY WOLF OPTIMIZER (GWO) and RPS-I-GWO
#=====================================================================
def gwo_spring(pop_size=P, max_gens=I):
    population = lower_bounds + np.random.rand(pop_size,3)*(upper_bounds - lower_bounds)
    fitnesses  = np.array([spring_penalized_fitness(x) for x in population])

    for gen in range(max_gens):
        # identify alpha,beta,delta
        sort_idx = np.argsort(fitnesses)
        alpha_idx, beta_idx, delta_idx = sort_idx[0], sort_idx[1], sort_idx[2]
        alpha_pos = population[alpha_idx].copy()
        beta_pos  = population[beta_idx].copy()
        delta_pos = population[delta_idx].copy()

        a = 2.0 - 2.0*(gen/(max_gens-1))  # linearly from 2->0
        for i in range(pop_size):
            X = population[i]
            r1, r2 = np.random.rand(), np.random.rand()
            A1 = 2.0*a*r1 - a
            C1 = 2.0*r2
            Dalpha = abs(C1*alpha_pos - X)
            X1 = alpha_pos - A1*Dalpha

            r1, r2 = np.random.rand(), np.random.rand()
            A2 = 2.0*a*r1 - a
            C2 = 2.0*r2
            Dbeta = abs(C2*beta_pos - X)
            X2 = beta_pos - A2*Dbeta

            r1, r2 = np.random.rand(), np.random.rand()
            A3 = 2.0*a*r1 - a
            C3 = 2.0*r2
            Ddelta = abs(C3*delta_pos - X)
            X3 = delta_pos - A3*Ddelta

            newX = (X1+X2+X3)/3.0
            newX = clip_to_bounds(newX)
            newFit = spring_penalized_fitness(newX)
            if newFit < fitnesses[i]:
                population[i] = newX
                fitnesses[i]  = newFit

    best_idx = np.argmin(fitnesses)
    return population[best_idx], fitnesses[best_idx]

def rps_i_gwo_spring(pop_size=P, max_gens=I):
    population = lower_bounds + np.random.rand(pop_size,3)*(upper_bounds - lower_bounds)
    fitnesses  = np.array([spring_penalized_fitness(x) for x in population])

    alpha_max, beta_max = 1e-6, 1e-6
    best_idx = np.argmin(fitnesses)
    prev_best= fitnesses[best_idx]

    for gen in range(max_gens):
        # RPS-I
        population, fitnesses, alpha_max, beta_max, prev_best = update_rps_i(
            population, fitnesses, alpha_max, beta_max, prev_best
        )
        # GWO iteration
        sort_idx = np.argsort(fitnesses)
        alpha_idx, beta_idx, delta_idx = sort_idx[0], sort_idx[1], sort_idx[2]
        alpha_pos = population[alpha_idx].copy()
        beta_pos  = population[beta_idx].copy()
        delta_pos = population[delta_idx].copy()

        a = 2.0 - 2.0*(gen/(max_gens-1))
        for i in range(pop_size):
            X = population[i]
            r1, r2 = np.random.rand(), np.random.rand()
            A1 = 2.0*a*r1 - a
            C1 = 2.0*r2
            Dalpha = abs(C1*alpha_pos - X)
            X1 = alpha_pos - A1*Dalpha

            r1, r2 = np.random.rand(), np.random.rand()
            A2 = 2.0*a*r1 - a
            C2 = 2.0*r2
            Dbeta = abs(C2*beta_pos - X)
            X2 = beta_pos - A2*Dbeta

            r1, r2 = np.random.rand(), np.random.rand()
            A3 = 2.0*a*r1 - a
            C3 = 2.0*r2
            Ddelta = abs(C3*delta_pos - X)
            X3 = delta_pos - A3*Ddelta

            newX = (X1+X2+X3)/3.0
            newX = clip_to_bounds(newX)
            newFit = spring_penalized_fitness(newX)
            if newFit < fitnesses[i]:
                population[i] = newX
                fitnesses[i]  = newFit

    best_idx = np.argmin(fitnesses)
    return population[best_idx], fitnesses[best_idx]


#=====================================================================
# 7) WHALE OPTIMIZATION ALGORITHM (WOA) and RPS-I-WOA
#=====================================================================
def woa_spring(pop_size=P, max_gens=I):
    population = lower_bounds + np.random.rand(pop_size,3)*(upper_bounds - lower_bounds)
    fitnesses  = np.array([spring_penalized_fitness(x) for x in population])

    for gen in range(max_gens):
        best_idx = np.argmin(fitnesses)
        best_sol = population[best_idx].copy()
        best_fit = fitnesses[best_idx]
        a = 2.0 - 2.0*(gen/(max_gens-1))  # from 2->0
        b = 1.0

        for i in range(pop_size):
            A = 2.0*a*np.random.rand() - a
            C = 2.0*np.random.rand()
            p = np.random.rand()

            if p < 0.5:
                # encircling or search
                if abs(A) < 1.0:
                    # encircle
                    D = abs(C*best_sol - population[i])
                    newX = best_sol - A*D
                else:
                    # search
                    rand_idx = np.random.randint(pop_size)
                    X_rand   = population[rand_idx]
                    D = abs(C*X_rand - population[i])
                    newX = X_rand - A*D
            else:
                # bubble-net (spiral)
                dist = np.linalg.norm(best_sol - population[i])
                l = (np.random.rand()*2) -1 # in [-1,1]
                newX = (best_sol - population[i])
                newX = newX*np.exp(b*l)*np.cos(2.0*np.pi*l) + population[i]

            newX = clip_to_bounds(newX)
            newFit = spring_penalized_fitness(newX)
            if newFit < fitnesses[i]:
                population[i] = newX
                fitnesses[i]  = newFit

    best_idx = np.argmin(fitnesses)
    return population[best_idx], fitnesses[best_idx]

def rps_i_woa_spring(pop_size=P, max_gens=I):
    population = lower_bounds + np.random.rand(pop_size,3)*(upper_bounds - lower_bounds)
    fitnesses  = np.array([spring_penalized_fitness(x) for x in population])

    alpha_max, beta_max = 1e-6, 1e-6
    best_idx  = np.argmin(fitnesses)
    prev_best = fitnesses[best_idx]

    for gen in range(max_gens):
        # RPS-I
        population, fitnesses, alpha_max, beta_max, prev_best = update_rps_i(
            population, fitnesses, alpha_max, beta_max, prev_best
        )
        # WOA iteration
        best_idx = np.argmin(fitnesses)
        best_sol = population[best_idx].copy()
        best_fit = fitnesses[best_idx]
        a = 2.0 - 2.0*(gen/(max_gens-1))
        b = 1.0

        for i in range(pop_size):
            A = 2.0*a*np.random.rand() - a
            C = 2.0*np.random.rand()
            p = np.random.rand()

            if p<0.5:
                if abs(A) < 1.0:
                    D = abs(C*best_sol - population[i])
                    newX = best_sol - A*D
                else:
                    rand_idx = np.random.randint(pop_size)
                    X_rand   = population[rand_idx]
                    D = abs(C*X_rand - population[i])
                    newX = X_rand - A*D
            else:
                dist = np.linalg.norm(best_sol - population[i])
                l = (np.random.rand()*2) -1
                newX = (best_sol - population[i])*np.exp(b*l)*np.cos(2.0*np.pi*l) + population[i]

            newX = clip_to_bounds(newX)
            newFit = spring_penalized_fitness(newX)
            if newFit < fitnesses[i]:
                population[i] = newX
                fitnesses[i]  = newFit

    best_idx = np.argmin(fitnesses)
    return population[best_idx], fitnesses[best_idx]


#=====================================================================
# 8) HARRIS HAWKS OPTIMIZATION (HHO) and RPS-I-HHO
#=====================================================================
def hho_spring(pop_size=P, max_gens=I):
    population = lower_bounds + np.random.rand(pop_size,3)*(upper_bounds - lower_bounds)
    fitnesses  = np.array([spring_penalized_fitness(x) for x in population])

    for gen in range(max_gens):
        best_idx = np.argmin(fitnesses)
        best_fit = fitnesses[best_idx]
        best_sol = population[best_idx].copy()

        # E_0 from -1 -> +1
        E_0 = -1.0 + 2.0*(gen/(max_gens-1))

        for i in range(pop_size):
            x_i = population[i]
            fit_i = fitnesses[i]
            r1 = np.random.rand()
            r2 = np.random.rand()
            if abs(E_0) >= 1:
                # exploration
                rand_idx = np.random.randint(pop_size)
                X_rand   = population[rand_idx]
                q = np.random.rand()
                D_rand = abs(q*X_rand - x_i)
                newX = X_rand - r1*D_rand
            else:
                # exploitation
                D_best = abs(r2*best_sol - x_i)
                L_J = 2.0*(1-r2)
                if np.random.rand()<0.5:
                    # soft besiege
                    newX = best_sol - E_0*D_best
                else:
                    # hard besiege
                    newX = (best_sol - E_0*D_best) - r1*L_J*D_best
            newX = clip_to_bounds(newX)
            newFit = spring_penalized_fitness(newX)
            if newFit < fitnesses[i]:
                population[i] = newX
                fitnesses[i]  = newFit

    best_idx = np.argmin(fitnesses)
    return population[best_idx], fitnesses[best_idx]

def rps_i_hho_spring(pop_size=P, max_gens=I):
    population = lower_bounds + np.random.rand(pop_size,3)*(upper_bounds - lower_bounds)
    fitnesses  = np.array([spring_penalized_fitness(x) for x in population])

    alpha_max, beta_max = 1e-6, 1e-6
    best_idx  = np.argmin(fitnesses)
    prev_best = fitnesses[best_idx]

    for gen in range(max_gens):
        # RPS-I
        population, fitnesses, alpha_max, beta_max, prev_best = update_rps_i(
            population, fitnesses, alpha_max, beta_max, prev_best
        )
        # HHO iteration
        best_idx = np.argmin(fitnesses)
        best_fit = fitnesses[best_idx]
        best_sol = population[best_idx].copy()

        E_0 = -1.0 + 2.0*(gen/(max_gens-1))

        for i in range(pop_size):
            x_i = population[i]
            fit_i = fitnesses[i]
            r1 = np.random.rand()
            r2 = np.random.rand()
            if abs(E_0)>=1:
                rand_idx = np.random.randint(pop_size)
                X_rand   = population[rand_idx]
                q = np.random.rand()
                D_rand = abs(q*X_rand - x_i)
                newX = X_rand - r1*D_rand
            else:
                D_best = abs(r2*best_sol - x_i)
                L_J = 2.0*(1-r2)
                if np.random.rand()<0.5:
                    newX = best_sol - E_0*D_best
                else:
                    newX = (best_sol - E_0*D_best) - r1*L_J*D_best
            newX = clip_to_bounds(newX)
            newFit = spring_penalized_fitness(newX)
            if newFit < fitnesses[i]:
                population[i] = newX
                fitnesses[i]  = newFit

    best_idx = np.argmin(fitnesses)
    return population[best_idx], fitnesses[best_idx]

#=====================================================================
# 9) MAIN DEMO: RUN ALL 12 ALGORITHMS
#=====================================================================
if __name__=="__main__":
    np.random.seed(0)  # for reproducibility

    algs = {
      "GA": ga_spring,
      "RPS-I-GA": rps_i_ga_spring,
      "PSO": pso_spring,
      "RPS-I-PSO": rps_i_pso_spring,
      "DE": de_spring,
      "RPS-I-DE": rps_i_de_spring,
      "GWO": gwo_spring,
      "RPS-I-GWO": rps_i_gwo_spring,
      "WOA": woa_spring,
      "RPS-I-WOA": rps_i_woa_spring,
      "HHO": hho_spring,
      "RPS-I-HHO": rps_i_hho_spring,
    }

    pop_size = P
    max_gens = I

    # Run each algorithm once (or multiple times as needed).
    for name, func in algs.items():
        best_sol, best_fit = func(pop_size=pop_size, max_gens=max_gens)
        print(f"Algorithm: {name}")
        print(f"  Best solution: x = {best_sol}")
        print(f"  Best penalized fitness = {best_fit:.6f}")
        print(f"  Actual objective f(x) = {spring_objective(best_sol):.6f}")
        # Check constraints
        constraint_vals = spring_constraints(best_sol)
        feasible = all(g<=0 for g in constraint_vals)
        print(f"  Feasible? {feasible}, constraints= {constraint_vals}")
        print("------------------------------------------------------------")
