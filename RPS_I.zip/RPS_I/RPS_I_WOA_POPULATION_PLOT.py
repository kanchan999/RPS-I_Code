# Code for visualization (signature) of population in WOA and RPS-I-WOA (Figure 12)
# Paper title: Regenerative Population Strategy-I: A Dynamic Methodology to Mitigate
#              Structural Bias in Metaheuristic Algorithms)
# Author: Kanchan Rajwar
# For assistance, contact: kanchanrajwar1519@gmail.com
# ======================================================================================================================
# ======================================================================================================================

import numpy as np
import matplotlib.pyplot as plt

# 1) Random Objective Function
def random_function(x, y):
    """
    Returns a random value in [0,1], which we aim to minimize.
    """
    return np.random.rand()

# 2) Global Parameters
pop_size = 10000      # Number of whales
num_generations = 10  # Number of iterations
grid_size = 100       # For visualization grid
cell_size = 1 / grid_size

# WOA constants
# a: linearly decreased from 2 to 0 over the iterations
# b: constant for spiral (commonly b=1,2, etc.). We'll use b=1 for standard example.

# ---------------------------
# Utility: Diversity & Improvement
# ---------------------------
def calculate_diversity(population):
    """
    Population diversity (alpha) as the sum of Euclidean distances from the mean position.
    """
    mean_pos = np.mean(population, axis=0)
    return np.sum(np.linalg.norm(population - mean_pos, axis=1))

def calculate_improvement_rate(prev_best, curr_best):
    """
    Improvement rate (beta) as the relative change in the best (lowest) score.
    """
    return (prev_best - curr_best) / (curr_best + 1e-9)

# ---------------------------
# One Iteration of Standard WOA (Encircling / Bubble-net / Search)
# ---------------------------
def woa_one_iteration(population, scores, iteration, max_iterations):
    """
    Perform one iteration of standard Whale Optimization Algorithm in 2D:
      - Find the current best solution
      - For each whale:
        * Decide if we do encircling/bubble-net or search
        * Parameter a decreases linearly from 2 -> 0
    Returns updated population and scores.
    """
    pop_size, _ = population.shape

    # Identify best solution
    best_idx = np.argmin(scores)
    best_score = scores[best_idx]
    best_pos = population[best_idx].copy()

    # linearly decrease a from 2->0
    a = 2.0 - 2.0 * (iteration / (max_iterations - 1))  # e.g. from 2.0 down to 0.0
    b = 1.0  # Spiral constant

    new_population = np.copy(population)
    new_scores = np.copy(scores)

    for i in range(pop_size):
        whale = population[i]
        r1 = np.random.rand()
        r2 = np.random.rand()

        A = 2.0 * a * r1 - a      # in [-a, a]
        C = 2.0 * r2             # in [0, 2]
        p = np.random.rand()     # switch threshold

        dist_to_best = np.linalg.norm(whale - best_pos)

        if p < 0.5:
            # Encircling or Search
            if abs(A) < 1.0:
                # Encircling prey
                D = abs(C * best_pos - whale)
                new_pos = best_pos - A * D
            else:
                # Search for prey (random whale)
                rand_idx = np.random.randint(pop_size)
                rand_whale = population[rand_idx]
                D = abs(C * rand_whale - whale)
                new_pos = rand_whale - A * D
        else:
            # Bubble-net (spiral)
            # distance from best
            D_prime = dist_to_best
            # l in [-1,1]
            l = (np.random.rand() * 2) - 1
            # b is the spiral constant
            # The standard spiral eq for WOA: X(t+1) = D' * e^(b*l)*cos(2*pi*l) + X*
            # But we typically do:  (X* - X(t)) * e^(b*l)*cos(...) + X(t)
            # We'll do a simplified version consistent with typical code:
            new_pos = (best_pos - whale)
            new_pos = new_pos * np.exp(b * l) * np.cos(2.0 * np.pi * l) + whale

        new_pos = np.clip(new_pos, 0.0, 1.0)

        new_score = random_function(*new_pos)
        # Greedy update
        if new_score < new_scores[i]:
            new_population[i] = new_pos
            new_scores[i] = new_score

    return new_population, new_scores

# ---------------------------
# RPS-I Step
# ---------------------------
def apply_rps_i(population, scores, alpha_max, beta_max, prev_best):
    """
    Calculate alpha (diversity), beta (improvement rate), then gamma.
    Reinitialize part of the population, preserving the best.
    """
    pop_size = len(population)
    curr_best_idx = np.argmin(scores)
    curr_best_score = scores[curr_best_idx]

    # alpha = diversity
    alpha = calculate_diversity(population)
    alpha_max = max(alpha_max, alpha)

    # beta = improvement
    beta = calculate_improvement_rate(prev_best, curr_best_score)
    beta_max = max(beta_max, beta)

    # gamma
    gamma = 0.5 * (alpha / alpha_max) + 0.5 * (beta / beta_max)
    gamma = np.clip(gamma, 0, 1)

    # how many to reinit
    num_to_regen = int(np.floor((1 - gamma) * (pop_size - 1)))
    print(f"    gamma={gamma:.4f}, reinitialize={num_to_regen}")

    if num_to_regen > 0:
        indices = np.arange(pop_size)
        # preserve best
        indices = np.delete(indices, curr_best_idx)
        if len(indices) > 0:
            regen_indices = np.random.choice(indices, min(num_to_regen, len(indices)), replace=False)
            for idx in regen_indices:
                population[idx] = np.random.rand(2)
                scores[idx] = random_function(*population[idx])

    new_best_idx = np.argmin(scores)
    new_best_score = scores[new_best_idx]
    updated_prev_best = min(prev_best, new_best_score)
    return population, scores, alpha_max, beta_max, updated_prev_best

# ---------------------------
# Runner: WOA vs. RPS-I-WOA
# ---------------------------
def run_woa_and_capture_population(replace_random=False):
    """
    Run WOA for num_generations in 2D. If replace_random=True, apply RPS-I each iteration.
    Returns a dictionary of population snapshots for each iteration.
    """
    # Initialize population in [0,1]^2
    population = np.random.rand(pop_size, 2)
    scores = np.array([random_function(*ind) for ind in population])

    # track best
    best_idx = np.argmin(scores)
    best_score = scores[best_idx]

    # RPS-I tracking
    if replace_random:
        alpha_max = 1e-6
        beta_max = 1e-6
        prev_best = best_score

    population_snapshots = {0: population.copy()}
    empty_cells_per_iteration = []

    for gen in range(num_generations):
        # Occupancy grid (for “signature” visualization)
        occupied = np.zeros((grid_size, grid_size), dtype=bool)
        for pos in population:
            gx = int(pos[0] // cell_size)
            gy = int(pos[1] // cell_size)
            occupied[gx, gy] = True
        num_empty_cells = np.sum(~occupied)
        empty_cells_per_iteration.append(num_empty_cells)

        if replace_random:
            print(f"Generation {gen}:")
            population, scores, alpha_max, beta_max, prev_best = apply_rps_i(
                population, scores, alpha_max, beta_max, prev_best
            )

        # Standard WOA step
        population, scores = woa_one_iteration(population, scores, gen, num_generations)

        # Update best
        best_idx = np.argmin(scores)
        best_score = scores[best_idx]

        # Store snapshot
        population_snapshots[gen + 1] = population.copy()

    return empty_cells_per_iteration, population_snapshots

# ---------------------------
# Run WOA (standard) and RPS-I-WOA
# ---------------------------
_, population_snapshots_woa    = run_woa_and_capture_population(replace_random=False)
_, population_snapshots_rpsiwoa = run_woa_and_capture_population(replace_random=True)

# ---------------------------
# Visualization of Snapshots
# ---------------------------
for generation in range(num_generations + 1):
    fig, axs = plt.subplots(1, 2, figsize=(12, 6))

    # Standard WOA
    axs[0].scatter(population_snapshots_woa[generation][:, 0],
                   population_snapshots_woa[generation][:, 1],
                   c="black", s=10, alpha=1.0)
    axs[0].set_title("WOA - Generation: {}".format(generation), fontsize=20)
    axs[0].set_xlim(0, 1)
    axs[0].set_ylim(0, 1)
    axs[0].set_xlabel("X", fontsize=15)
    axs[0].set_ylabel("Y", fontsize=15)
    axs[0].tick_params(axis='both', labelsize=15)
    # Draw the 100x100 grid lines
    for i in range(1, grid_size):
        axs[0].axhline(i * cell_size, color='gray', linestyle='-', linewidth=0.5)
        axs[0].axvline(i * cell_size, color='gray', linestyle='-', linewidth=0.5)
    axs[0].grid(False)

    # RPS-I-WOA
    axs[1].scatter(population_snapshots_rpsiwoa[generation][:, 0],
                   population_snapshots_rpsiwoa[generation][:, 1],
                   c="black", s=10, alpha=1.0)
    axs[1].set_title("RPS-I-WOA - Generation: {}".format(generation), fontsize=20)
    axs[1].set_xlim(0, 1)
    axs[1].set_ylim(0, 1)
    axs[1].set_xlabel("X", fontsize=15)
    axs[1].set_ylabel("Y", fontsize=15)
    axs[1].tick_params(axis='both', labelsize=15)
    for i in range(1, grid_size):
        axs[1].axhline(i * cell_size, color='gray', linestyle='-', linewidth=0.5)
        axs[1].axvline(i * cell_size, color='gray', linestyle='-', linewidth=0.5)
    axs[1].grid(False)

    plt.tight_layout()
    plt.show()
