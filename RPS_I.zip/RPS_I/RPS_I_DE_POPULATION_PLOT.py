# Code for visualization (signature) of population in DE and RPS-I-DE (Figure 8)
# Paper title: Regenerative Population Strategy-I: A Dynamic Methodology to Mitigate
#              Structural Bias in Metaheuristic Algorithms)
# Author: Kanchan Rajwar
# For assistance, contact: kanchanrajwar1519@gmail.com
# =====================================================================================================================
# =====================================================================================================================

import numpy as np
import matplotlib.pyplot as plt

# ---------------------------
# Random objective function
# ---------------------------
def random_function(x, y):
    """
    Returns a random value in [0,1], which we aim to MINIMIZE.
    """
    return np.random.rand()

# ---------------------------
# Global parameters
# ---------------------------
pop_size = 10000     # Number of individuals
num_generations = 10 # Number of iterations (generations)

# DE parameters
F = 0.5              # Differential weight (scaling factor)
CR = 0.5             # Crossover rate

# Grid parameters for visualization (dividing [0,1]^2 into a 100x100 grid)
grid_size = 100
cell_size = 1 / grid_size  # Size of each cell in the grid


# ---------------------------
# DE Binomial Crossover (2D)
# ---------------------------
def binomial_crossover(target, donor, CR=0.5):
    """
    Perform binomial crossover in 2D: For each dimension, we choose from 'donor'
    with probability CR, else from 'target'. At least one dimension must come from 'donor'.
    """
    trial = np.copy(target)
    # We ensure at least one dimension is from the donor
    rand_dim = np.random.randint(2)  # 0 or 1
    for d in range(2):
        if np.random.rand() < CR or d == rand_dim:
            trial[d] = donor[d]
    return trial


# ---------------------------
# Standard DE Step
# ---------------------------
def de_one_iteration(population, scores):
    """
    Perform one generation (iteration) of DE/rand/1/bin in 2D:
      - For each individual i:
        * Select three distinct random indices (r1, r2, r3 != i)
        * donor = pop[r1] + F * (pop[r2] - pop[r3])
        * trial = binomial_crossover(target=pop[i], donor, CR)
        * Evaluate 'trial'
        * If better, replace pop[i]
    Returns the updated population and updated scores.
    """
    new_population = np.copy(population)
    new_scores = np.copy(scores)

    for i in range(pop_size):
        # Choose 3 distinct random indices r1,r2,r3 != i
        idxs = np.arange(pop_size)
        idxs = idxs[idxs != i]
        r1, r2, r3 = np.random.choice(idxs, 3, replace=False)
        # Donor
        donor = population[r1] + F * (population[r2] - population[r3])
        # Clip donor to [0,1]^2
        donor = np.clip(donor, 0, 1)
        # Binomial crossover
        trial = binomial_crossover(population[i], donor, CR=CR)
        # Clip trial
        trial = np.clip(trial, 0, 1)
        # Evaluate trial
        trial_score = random_function(*trial)
        # Greedy selection
        if trial_score < new_scores[i]:
            new_population[i] = trial
            new_scores[i] = trial_score

    return new_population, new_scores


# ---------------------------
# Utility: Diversity & Improvement
# ---------------------------
def calculate_diversity(population):
    """
    Population diversity (alpha) as the sum of Euclidean distances from the mean position.
    """
    mean_pos = np.mean(population, axis=0)
    return np.sum(np.linalg.norm(population - mean_pos, axis=1))

def calculate_improvement_rate(prev_best, curr_best):
    """
    Improvement rate (beta) as the relative change in the best (lowest) score.
    """
    return (prev_best - curr_best) / (curr_best + 1e-9)


# ---------------------------
# DE Runner (with or without RPS-I)
# ---------------------------
def run_de_and_capture_population(replace_random=False):
    """
    Run Differential Evolution in 2D for num_generations, capturing snapshots.

    - When replace_random=False, it's a standard DE.
    - When replace_random=True, it's RPS-I-DE:
        * Each generation, compute alpha (diversity) & beta (improvement rate)
        * Combine them into gamma = 0.5*(alpha/alpha_max) + 0.5*(beta/beta_max)
        * Re-initialize floor((1-gamma)*(pop_size-1)) individuals, preserving the best.
    """
    # 1) Initialize population in [0,1]^2
    population = np.random.rand(pop_size, 2)
    # Evaluate initial scores
    scores = np.array([random_function(*ind) for ind in population])

    # Track best
    best_index = np.argmin(scores)
    best_score = scores[best_index]

    # RPS-I tracking
    if replace_random:
        alpha_max = 1e-6
        beta_max = 1e-6
        prev_best = best_score

    # Dictionary of snapshots
    population_snapshots = {0: population.copy()}
    empty_cells_per_iteration = []

    # 2) Main loop
    for generation in range(num_generations):
        # Create occupancy grid (for “signature”)
        occupied_cells = np.zeros((grid_size, grid_size), dtype=bool)
        for pos in population:
            gx = int(pos[0] // cell_size)
            gy = int(pos[1] // cell_size)
            occupied_cells[gx, gy] = True
        num_empty_cells = np.sum(~occupied_cells)
        empty_cells_per_iteration.append(num_empty_cells)

        # Perform one DE generation
        new_population, new_scores = de_one_iteration(population, scores)

        # Update best
        curr_best_index = np.argmin(new_scores)
        curr_best_score = new_scores[curr_best_index]

        # RPS-I
        if replace_random:
            # alpha
            alpha = calculate_diversity(new_population)
            alpha_max = max(alpha_max, alpha)

            # beta
            beta = calculate_improvement_rate(prev_best, curr_best_score)
            beta_max = max(beta_max, beta)

            # gamma
            gamma = 0.5*(alpha/alpha_max) + 0.5*(beta/beta_max)
            gamma = np.clip(gamma, 0, 1)

            # re-init some fraction
            num_to_regenerate = int(np.floor((1 - gamma)*(pop_size - 1)))
            print(f"Generation {generation}: gamma={gamma:.4f}, reinitialize={num_to_regenerate}")
            # preserve best
            best_idx = curr_best_index
            indices = np.arange(pop_size)
            indices = np.delete(indices, best_idx)
            if num_to_regenerate > 0 and len(indices) > 0:
                regen_indices = np.random.choice(indices, min(num_to_regenerate, len(indices)), replace=False)
                for idx in regen_indices:
                    new_population[idx] = np.random.rand(2)
                    # Re-evaluate the re-initialized solution
                    new_scores[idx] = random_function(*new_population[idx])

            # update prev_best
            final_best_idx = np.argmin(new_scores)
            final_best_score = new_scores[final_best_idx]
            prev_best = min(prev_best, final_best_score)

        # update population
        population = new_population
        scores = new_scores
        best_index = np.argmin(scores)
        best_score = scores[best_index]

        # Store snapshot
        population_snapshots[generation+1] = population.copy()

    return empty_cells_per_iteration, population_snapshots


# ---------------------------
# Run DE standard vs. RPS-I-DE
# ---------------------------
_, population_snapshots_de = run_de_and_capture_population(replace_random=False)
_, population_snapshots_rpside = run_de_and_capture_population(replace_random=True)

# ---------------------------
# Visualization
# ---------------------------
for generation in range(num_generations + 1):
    fig, axs = plt.subplots(1, 2, figsize=(12, 6))

    # Standard DE
    axs[0].scatter(population_snapshots_de[generation][:, 0],
                   population_snapshots_de[generation][:, 1],
                   c="black", s=10, alpha=1.0)
    axs[0].set_title("DE - Generation: {}".format(generation), fontsize=20)
    axs[0].set_xlim(0, 1)
    axs[0].set_ylim(0, 1)
    axs[0].set_xlabel("X", fontsize=15)
    axs[0].set_ylabel("Y", fontsize=15)
    axs[0].tick_params(axis='both', labelsize=15)
    for i in range(1, grid_size):
        axs[0].axhline(i * cell_size, color='gray', linestyle='-', linewidth=0.5)
        axs[0].axvline(i * cell_size, color='gray', linestyle='-', linewidth=0.5)
    axs[0].grid(False)

    # RPS-I-DE
    axs[1].scatter(population_snapshots_rpside[generation][:, 0],
                   population_snapshots_rpside[generation][:, 1],
                   c="black", s=10, alpha=1.0)
    axs[1].set_title("RPS-I-DE - Generation: {}".format(generation), fontsize=20)
    axs[1].set_xlim(0, 1)
    axs[1].set_ylim(0, 1)
    axs[1].set_xlabel("X", fontsize=15)
    axs[1].set_ylabel("Y", fontsize=15)
    axs[1].tick_params(axis='both', labelsize=15)
    for i in range(1, grid_size):
        axs[1].axhline(i * cell_size, color='gray', linestyle='-', linewidth=0.5)
        axs[1].axvline(i * cell_size, color='gray', linestyle='-', linewidth=0.5)
    axs[1].grid(False)

    plt.tight_layout()
    plt.show()
