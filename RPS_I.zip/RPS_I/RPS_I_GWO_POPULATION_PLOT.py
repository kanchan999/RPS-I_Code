# Code for visualization (signature) of population in GWO and RPS-I-GWO (Figure 10)
# Paper title: Regenerative Population Strategy-I: A Dynamic Methodology to Mitigate
#              Structural Bias in Metaheuristic Algorithms)
# Author: Kanchan Rajwar
# For assistance, contact: kanchanrajwar1519@gmail.com
# ======================================================================================================================
# ======================================================================================================================
import numpy as np
import matplotlib.pyplot as plt

# 1) Random Objective Function
def random_function(x, y):
    """
    Returns a random value in [0,1], to be MINIMIZED.
    """
    return np.random.rand()

# 2) Global Parameters
pop_size = 10000      # Number of wolves in the pack
num_generations = 10  # Number of iterations
grid_size = 100       # For visualization grid
cell_size = 1 / grid_size

# ---------------------------
# Utility: Diversity & Improvement
# ---------------------------
def calculate_diversity(population):
    """
    Population diversity (alpha) as the sum of Euclidean distances from the mean position.
    """
    mean_pos = np.mean(population, axis=0)
    return np.sum(np.linalg.norm(population - mean_pos, axis=1))

def calculate_improvement_rate(prev_best, curr_best):
    """
    Improvement rate (beta) as the relative change in the best (lowest) score.
    """
    return (prev_best - curr_best) / (curr_best + 1e-9)

# ---------------------------
# GWO Update (One Iteration)
# ---------------------------
def gwo_one_iteration(population, scores, iteration, max_iterations):
    """
    Perform one iteration of standard Grey Wolf Optimizer in 2D:
      - Identify alpha, beta, delta
      - 'a' linearly decreases from 2 -> 0
      - Update each wolf based on alpha, beta, delta
    Returns the updated population and scores.
    """
    pop_size, _ = population.shape

    # Sort by ascending score to find alpha, beta, delta
    sorted_idx = np.argsort(scores)
    alpha_idx, beta_idx, delta_idx = sorted_idx[0], sorted_idx[1], sorted_idx[2]
    alpha_score, beta_score, delta_score = scores[alpha_idx], scores[beta_idx], scores[delta_idx]
    alpha_pos = population[alpha_idx].copy()
    beta_pos  = population[beta_idx].copy()
    delta_pos = population[delta_idx].copy()

    # linearly decrease 'a' from 2 -> 0
    a = 2.0 - (2.0 * iteration / (max_iterations - 1))

    new_population = np.copy(population)
    new_scores     = np.copy(scores)

    for i in range(pop_size):
        wolf = population[i]
        # For each of alpha, beta, delta, compute new X
        r1, r2 = np.random.rand(), np.random.rand()
        A1 = 2.0 * a * r1 - a
        C1 = 2.0 * r2
        D_alpha = abs(C1 * alpha_pos - wolf)
        X1 = alpha_pos - A1 * D_alpha

        r1, r2 = np.random.rand(), np.random.rand()
        A2 = 2.0 * a * r1 - a
        C2 = 2.0 * r2
        D_beta = abs(C2 * beta_pos - wolf)
        X2 = beta_pos - A2 * D_beta

        r1, r2 = np.random.rand(), np.random.rand()
        A3 = 2.0 * a * r1 - a
        C3 = 2.0 * r2
        D_delta = abs(C3 * delta_pos - wolf)
        X3 = delta_pos - A3 * D_delta

        new_pos = (X1 + X2 + X3) / 3.0
        # Clip to [0,1]^2
        new_pos = np.clip(new_pos, 0, 1)

        # Evaluate new position
        new_score = random_function(*new_pos)

        # Greedy update
        if new_score < new_scores[i]:
            new_population[i] = new_pos
            new_scores[i] = new_score

    return new_population, new_scores

# ---------------------------
# RPS-I Step
# ---------------------------
def apply_rps_i(population, scores, alpha_max, beta_max, prev_best):
    """
    - Compute alpha (population diversity), beta (improvement rate), then gamma
    - Reinitialize part of the pack, preserving best
    Returns updated population, scores, new alpha_max, beta_max, new best reference.
    """
    pop_size = len(population)

    # Current best
    curr_best_idx = np.argmin(scores)
    curr_best_score = scores[curr_best_idx]

    # alpha = diversity
    alpha = calculate_diversity(population)
    alpha_max = max(alpha_max, alpha)

    # beta = improvement rate
    beta = calculate_improvement_rate(prev_best, curr_best_score)
    beta_max = max(beta_max, beta)

    # gamma
    gamma = 0.5*(alpha / alpha_max) + 0.5*(beta / beta_max)
    gamma = np.clip(gamma, 0, 1)

    # number to reinit
    num_to_regen = int(np.floor((1 - gamma)*(pop_size - 1)))
    print(f"    gamma={gamma:.4f}, reinitialize={num_to_regen}")

    if num_to_regen > 0:
        # preserve the best
        indices = np.arange(pop_size)
        indices = np.delete(indices, curr_best_idx)
        if len(indices) > 0:
            regen_indices = np.random.choice(indices, min(num_to_regen, len(indices)), replace=False)
            for idx in regen_indices:
                population[idx] = np.random.rand(2)  # random in [0,1]
                scores[idx] = random_function(*population[idx])

    # update prev_best
    new_best_idx = np.argmin(scores)
    new_best_score = scores[new_best_idx]
    updated_prev_best = min(prev_best, new_best_score)
    return population, scores, alpha_max, beta_max, updated_prev_best

# ---------------------------
# Main Runner: GWO vs. RPS-I-GWO
# ---------------------------
def run_gwo_and_capture_population(replace_random=False):
    """
    Run GWO for num_generations, capturing snapshots.
    - When replace_random=False: standard GWO
    - When replace_random=True: RPS-I-GWO
    """
    # Initialize population in [0,1]^2
    population = np.random.rand(pop_size, 2)
    # Evaluate initial scores
    scores = np.array([random_function(*ind) for ind in population])

    # track best
    best_idx = np.argmin(scores)
    best_score = scores[best_idx]

    # RPS-I
    if replace_random:
        alpha_max = 1e-6
        beta_max = 1e-6
        prev_best = best_score

    # Dictionary for snapshots
    population_snapshots = {0: population.copy()}
    empty_cells_per_iteration = []

    # GWO loop
    for gen in range(num_generations):
        # Occupancy grid for “signature”
        occupied = np.zeros((grid_size, grid_size), dtype=bool)
        for pos in population:
            gx = int(pos[0] // cell_size)
            gy = int(pos[1] // cell_size)
            occupied[gx, gy] = True
        num_empty_cells = np.sum(~occupied)
        empty_cells_per_iteration.append(num_empty_cells)

        # If RPS-I, apply it first (so reinit occurs, then do GWO step)
        if replace_random:
            print(f"Generation {gen}:")
            population, scores, alpha_max, beta_max, prev_best = apply_rps_i(
                population, scores, alpha_max, beta_max, prev_best
            )

        # Perform standard GWO iteration
        population, scores = gwo_one_iteration(population, scores, gen, num_generations)

        # Update best
        best_idx = np.argmin(scores)
        best_score = scores[best_idx]

        # Store snapshot
        population_snapshots[gen + 1] = population.copy()

    return empty_cells_per_iteration, population_snapshots

# ---------------------------
# Run Standard GWO and RPS-I-GWO
# ---------------------------
_, population_snapshots_gwo    = run_gwo_and_capture_population(replace_random=False)
_, population_snapshots_rpsgwo = run_gwo_and_capture_population(replace_random=True)

# ---------------------------
# Visualization of Snapshots
# ---------------------------
for generation in range(num_generations + 1):
    fig, axs = plt.subplots(1, 2, figsize=(12, 6))

    # Standard GWO
    axs[0].scatter(population_snapshots_gwo[generation][:, 0],
                   population_snapshots_gwo[generation][:, 1],
                   c="black", s=10, alpha=1.0)
    axs[0].set_title("GWO - Generation: {}".format(generation), fontsize=20)
    axs[0].set_xlim(0, 1)
    axs[0].set_ylim(0, 1)
    axs[0].set_xlabel("X", fontsize=15)
    axs[0].set_ylabel("Y", fontsize=15)
    axs[0].tick_params(axis='both', labelsize=15)
    # optional grid lines in the 100x100
    for i in range(1, grid_size):
        axs[0].axhline(i * cell_size, color='gray', linestyle='-', linewidth=0.5)
        axs[0].axvline(i * cell_size, color='gray', linestyle='-', linewidth=0.5)
    axs[0].grid(False)

    # RPS-I-GWO
    axs[1].scatter(population_snapshots_rpsgwo[generation][:, 0],
                   population_snapshots_rpsgwo[generation][:, 1],
                   c="black", s=10, alpha=1.0)
    axs[1].set_title("RPS-I-GWO - Generation: {}".format(generation), fontsize=20)
    axs[1].set_xlim(0, 1)
    axs[1].set_ylim(0, 1)
    axs[1].set_xlabel("X", fontsize=15)
    axs[1].set_ylabel("Y", fontsize=15)
    axs[1].tick_params(axis='both', labelsize=15)
    for i in range(1, grid_size):
        axs[1].axhline(i * cell_size, color='gray', linestyle='-', linewidth=0.5)
        axs[1].axvline(i * cell_size, color='gray', linestyle='-', linewidth=0.5)
    axs[1].grid(False)

    plt.tight_layout()
    plt.show()
