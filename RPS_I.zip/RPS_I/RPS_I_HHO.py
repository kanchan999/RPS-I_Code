# Code for Structural Bias Determination in HHO and RPS-I-HHO Using the Generalized Signature Test
# Paper title: Regenerative Population Strategy-I: A Dynamic Methodology to Mitigate
#              Structural Bias in Metaheuristic Algorithms)
# Author: Kanchan Rajwar
# For assistance, contact: kanchanrajwar1519@gmail.com
# ======================================================================================================================
# ======================================================================================================================
import numpy as np
import random
import matplotlib.pyplot as plt
import matplotlib.patches as patches

# ======================================================================================================================
# Harris Hawks Optimization (HHO) Parameters
# E_0: "escape energy" or "initial energy" changing from -1 to +1 linearly through the iterations.
# The absolute value |E_0| decides exploration (|E_0| >= 1) or exploitation (|E_0| < 1).
# ======================================================================================================================

def objective_function(solution):
    """
    Uniformly random objective function as per the study.
    The returned value is in [0,1], and we want to MINIMIZE it.
    """
    return np.random.uniform(0, 1)

# ======================================================================================================================
def initialize_population(pop_size, dimensions, bounds=(0,1)):
    """
    Initialize the population of hawks in [0,1]^dimensions.
    """
    return np.random.uniform(bounds[0], bounds[1], (pop_size, dimensions))

# ======================================================================================================================
def calculate_population_diversity(population):
    """
    Calculate diversity (alpha) as the sum of Euclidean distances from the mean position.
    A higher value indicates a more spread-out (diverse) population.
    """
    mean_position = np.mean(population, axis=0)
    diversity = np.sum([np.linalg.norm(ind - mean_position) for ind in population])
    return diversity

# ======================================================================================================================
def calculate_improvement_rate(fitness_best_prev, fitness_best_current):
    """
    Calculate improvement rate (beta) as the relative change in the best (lowest) fitness.
    A higher value indicates faster convergence.
    """
    return (fitness_best_prev - fitness_best_current) / (fitness_best_current + 1e-9)  # Avoid division by zero

# ======================================================================================================================
def calculate_gamma(alpha, alpha_max, beta, beta_max, w_alpha=0.5, w_beta=0.5):
    """
    Calculate the combined score gamma as a weighted sum of the normalized diversity (alpha/alpha_max)
    and improvement rate (beta/beta_max). gamma is clipped to [0,1].
    """
    alpha_max = max(alpha_max, alpha)
    beta_max = max(beta_max, beta)
    gamma = w_alpha * (alpha / alpha_max) + w_beta * (beta / beta_max)
    gamma = np.clip(gamma, 0, 1)
    return gamma, alpha_max, beta_max

# ======================================================================================================================
def calculate_ssf(population, dimensions, grid_cells=8):    #TOTAL GRID CELL = grid_cells^DIMENSION. SO HERE grid_cells=8,
                                                            # MEANS TOTAL GRID CELL = 8^3 = 512, DIMENSION IS TAKEN  3
    """
    Calculate the Signature Factor (SSF) based on the density of the population in a grid.
    This metric is the ratio of empty hypercubes to the total number of hypercubes.
    """
    grid_size = grid_cells
    grid = np.zeros((grid_size,) * dimensions)
    for individual in population:
        # Convert each coordinate to an integer index in the grid
        indices = tuple((individual * grid_size).astype(int) % grid_size)
        grid[indices] += 1
    empty_hypercubes = np.sum(grid == 0)
    return float(empty_hypercubes / (grid_size ** dimensions))  # normalized by total cell count

# ======================================================================================================================
def apply_rps_i(population, gamma, best_index=None, bounds=(0,1), print_info=False):
    """
    Apply RPS-I by regenerating a subset of the population based on gamma.
    The number of individuals to regenerate is:
       N_regen = floor((1 - gamma) * (P - 1))
    The best solution (best_index) is preserved.
    """
    N = len(population)
    num_to_regenerate = int(np.floor((1 - gamma) * (N - 1)))

    # Exclude the best solution from regeneration
    indices = np.arange(N)
    if best_index is not None:
        indices = np.delete(indices, best_index)

    if num_to_regenerate > 0 and len(indices) > 0:
        regen_indices = np.random.choice(indices, min(num_to_regenerate, len(indices)), replace=False)
        if print_info:
            print(f"    Regenerating hawks at indices: {regen_indices}")
        for i in regen_indices:
            population[i] = np.random.uniform(bounds[0], bounds[1], population.shape[1])

    return population

# ======================================================================================================================
# Standard Harris Hawks Optimization (HHO)
# ======================================================================================================================
def standard_hho(pop_size, dimensions, max_generations=100, bounds=(0,1)):
    """
    Standard HHO:
     - Initialize the population (hawks)
     - Each iteration:
       - Compute E_0 from -1 to +1 (linearly)
       - For each hawk i:
         - If |E_0| >= 1 -> exploration
         - If |E_0| < 1  -> exploitation
       - Update each hawk's position accordingly
       - Evaluate population, track best solution
       - Record SSF
    """

    # 1) Initialize hawks
    population = initialize_population(pop_size, dimensions, bounds)
    scores = np.array([objective_function(ind) for ind in population])

    # Identify best solution (the 'prey')
    best_index = np.argmin(scores)
    best_score = scores[best_index]
    best_pos = population[best_index].copy()

    ssf_values = []

    # 2) Main loop
    for gen in range(max_generations):
        # measure SSF
        ssf_values.append(calculate_ssf(population, dimensions))

        # E_0 changes from -1 (iteration=0) to +1 (iteration=max_generations-1)
        E_0 = -1.0 + 2.0 * (gen / (max_generations - 1))  # linear from [-1..+1]

        # For each hawk
        for i in range(pop_size):
            current_pos = population[i].copy()
            current_score = scores[i]

            # Random factors
            r1 = np.random.rand()
            r2 = np.random.rand()

            # If |E_0| >= 1 -> exploration
            if abs(E_0) >= 1:
                # Randomly select another hawk from population
                rand_index = np.random.randint(pop_size)
                X_rand = population[rand_index]
                # Move hawk i toward X_rand in a random manner
                q = np.random.rand()  # step coefficient
                D_rand = abs(q * X_rand - current_pos)
                new_pos = X_rand - r1 * D_rand
            else:
                # Exploitation
                # Dist from best
                D_best = abs(r2 * best_pos - current_pos)

                # "Jump strength" often used in HHO
                LJ = 2.0 * (1 - r2)  # A possible simplified jump factor

                # Probability switch for "soft/hard besiege"
                if np.random.rand() < 0.5:
                    # Soft besiege
                    new_pos = best_pos - E_0 * D_best
                else:
                    # Hard besiege
                    # Perform "jump" from the best solution
                    new_pos = (best_pos - E_0 * D_best) - r1 * LJ * (D_best)

            # Clip to the bounds
            new_pos = np.clip(new_pos, bounds[0], bounds[1])

            # Evaluate new position
            new_score = objective_function(new_pos)

            # Greedy selection
            if new_score < current_score:
                population[i] = new_pos
                scores[i] = new_score

        # Update best
        best_index = np.argmin(scores)
        best_score = scores[best_index]
        best_pos = population[best_index].copy()

    return ssf_values

# ======================================================================================================================
# RPS-I-HHO
# ======================================================================================================================
def rps_i_hho(pop_size, dimensions, max_generations=100, bounds=(0,1)):
    """
    Harris Hawks Optimization with RPS-I:
     - Each iteration:
       - Calculate alpha (diversity), beta (improvement rate), gamma
       - Re-initialize some hawks based on gamma
       - Then do the standard HHO update step
    """

    # 1) Initialize hawks
    population = initialize_population(pop_size, dimensions, bounds)
    scores = np.array([objective_function(ind) for ind in population])

    # Best hawk (prey)
    best_index = np.argmin(scores)
    best_score = scores[best_index]
    best_pos = population[best_index].copy()

    # RPS-I metrics
    alpha_max, beta_max = 1e-6, 1e-6
    fitness_best_prev = best_score

    ssf_values = []

    # 2) Main loop
    for gen in range(max_generations):
        # Identify current best
        best_index = np.argmin(scores)
        best_score = scores[best_index]
        best_pos = population[best_index].copy()

        # Calculate RPS-I metrics
        diversity = calculate_population_diversity(population)
        improvement = calculate_improvement_rate(fitness_best_prev, best_score)
        gamma, alpha_max, beta_max = calculate_gamma(diversity, alpha_max, improvement, beta_max)

        # Apply RPS-I
        num_to_regen = int(np.floor((1 - gamma) * (len(population) - 1)))
        print("------------------------------------------------------------------------------------------------------------------")
        print(f"Generation {gen}: gamma = {gamma:.4f}, reinitialize count = {num_to_regen}")
        population = apply_rps_i(population, gamma, best_index=best_index, bounds=bounds, print_info=True)

        # measure SSF after reinit
        ssf_after_reinit = calculate_ssf(population, dimensions)
        print(f"    SSF : {ssf_after_reinit:.4f}")
        ssf_values.append(ssf_after_reinit)

        # Now do the standard HHO update
        # Re-evaluate if population changed
        scores = np.array([objective_function(ind) for ind in population])
        best_index = np.argmin(scores)
        best_score = scores[best_index]
        best_pos = population[best_index].copy()

        # E_0 linearly from -1..+1
        E_0 = -1.0 + 2.0 * (gen / (max_generations - 1))

        for i in range(pop_size):
            current_pos = population[i].copy()
            current_score = scores[i]

            r1 = np.random.rand()
            r2 = np.random.rand()

            # Check exploration vs exploitation
            if abs(E_0) >= 1:
                # Exploration
                rand_index = np.random.randint(pop_size)
                X_rand = population[rand_index]
                q = np.random.rand()
                D_rand = abs(q * X_rand - current_pos)
                new_pos = X_rand - r1 * D_rand
            else:
                # Exploitation
                D_best = abs(r2 * best_pos - current_pos)
                LJ = 2.0 * (1 - r2)  # simplified jump factor

                if np.random.rand() < 0.5:
                    # Soft besiege
                    new_pos = best_pos - E_0 * D_best
                else:
                    # Hard besiege
                    new_pos = (best_pos - E_0 * D_best) - r1 * LJ * (D_best)

            new_pos = np.clip(new_pos, bounds[0], bounds[1])
            new_score = objective_function(new_pos)

            # Greedy selection
            if new_score < current_score:
                population[i] = new_pos
                scores[i] = new_score

        # Update best hawk for next iteration
        best_index = np.argmin(scores)
        best_score = scores[best_index]
        best_pos = population[best_index].copy()

        # Update for next iteration's improvement rate
        fitness_best_prev = best_score

    return ssf_values

# ======================================================================================================================
# Main Execution
# ======================================================================================================================
if __name__ == "__main__":
    # Parameters
    dimensions = 3         # Dimensionality of the problem ([0,1]^3)
    pop_size = 512         # Population size
    max_generations = 100  # Number of generations
    bounds = (0,1)

    # Run standard HHO
    ssf_values_hho = standard_hho(pop_size, dimensions, max_generations, bounds)

    # Run RPS-I-HHO
    ssf_values_rps_hho = rps_i_hho(pop_size, dimensions, max_generations, bounds)

    print("------------------------------------------------------------------------------------------------------------------")

    # Print SSF comparison for selected iterations
    print("SSF values for particular iterations of Standard HHO:")
    print(f"Iteration 0:  {ssf_values_hho[0]:.4f}")
    print(f"Iteration 24: {ssf_values_hho[24]:.4f}")
    print(f"Iteration 49: {ssf_values_hho[49]:.4f}")
    print(f"Iteration 74: {ssf_values_hho[74]:.4f}")
    print(f"Iteration 99: {ssf_values_hho[99]:.4f}")

    print("------------------------------------------------------------------------------------------------------------------")

    print("\nSSF values for particular iterations of RPS-I HHO:")
    print(f"Iteration 0:  {ssf_values_rps_hho[0]:.4f}")
    print(f"Iteration 24: {ssf_values_rps_hho[24]:.4f}")
    print(f"Iteration 49: {ssf_values_rps_hho[49]:.4f}")
    print(f"Iteration 74: {ssf_values_rps_hho[74]:.4f}")
    print(f"Iteration 99: {ssf_values_rps_hho[99]:.4f}")

    # Plot the results
    plt.figure(figsize=(10, 6))
    plt.plot(ssf_values_hho, label="HHO", marker='o', markersize=4, linewidth=2)
    plt.plot(ssf_values_rps_hho, label="RPS-I-HHO", marker='s', markersize=4, linewidth=2)
    plt.legend(fontsize=16)
    plt.xlim(0, max_generations)
    plt.ylim(0.3, 1)
    plt.xlabel("Iteration", fontsize=16)
    plt.ylabel("Signature Factor (η)", fontsize=16)
    plt.grid(True)

    # Add a thick border around the plot area
    border_thickness = 5
    plt.gca().add_patch(
        patches.Rectangle(
            (0, 0), 1, 1, transform=plt.gca().transAxes,
            linewidth=border_thickness, edgecolor='black', facecolor='none'
        )
    )

    plt.show()
    print("------------------------------------------------------------------------------------------------------------------")
# ======================================================================================================================
# ======================================================================================================================
