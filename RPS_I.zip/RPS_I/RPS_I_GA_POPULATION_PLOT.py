# Code for visualization (signature) of population in GA and RPS-I-GA (Figure 4)
# Paper title: Regenerative Population Strategy-I: A Dynamic Methodology to Mitigate
#              Structural Bias in Metaheuristic Algorithms)
# Author: Kanchan Rajwar
# For assistance, contact: kanchanrajwar1519@gmail.com
# =====================================================================================================================
# =====================================================================================================================

import numpy as np
import matplotlib.pyplot as plt

# ---------------------------
# Function and Parameter Setup
# ---------------------------
def random_function(x, y):
    """Returns a random value in [0,1], to be minimized."""
    return np.random.rand()

# GA parameters
pop_size = 10000       # Number of individuals in the population
num_generations = 10   # Number of generations (iterations)

# For simple GA operators
crossover_rate = 1.0   # Single-point crossover probability (always crossover)
mutation_rate  = 0.01  # Probability of mutating each gene

# Grid parameters for visualization (dividing [0,1]^2 into a 100x100 grid)
grid_size = 100
cell_size = 1 / grid_size  # Size of each cell in the grid

# ---------------------------
# GA Operator Implementations
# ---------------------------
def roulette_wheel_selection(population, scores):
    """
    Roulette-wheel selection. Since we want to minimize scores in [0,1],
    we define fitness = 1 - score (lower score => higher fitness).
    Then pick individuals proportionally to this fitness.
    """
    fitness = 1.0 - scores  # Convert cost to fitness
    total_fitness = np.sum(fitness)
    if total_fitness <= 1e-12:
        # Fallback: random selection if total_fitness is too small
        indices = np.random.randint(0, len(population), size=len(population))
        return population[indices]

    # Build the cumulative distribution
    cdf = np.cumsum(fitness / total_fitness)
    new_pop = []
    for _ in range(len(population)):
        r = np.random.rand()
        idx = np.searchsorted(cdf, r)
        new_pop.append(population[idx])

    return np.array(new_pop)

def single_point_crossover(parent1, parent2):
    """
    Single-point crossover in 2D.
    We pick one dimension as the crossover point (either x or y).
    """
    # Our "chromosome" length = 2 ( [x, y] )
    # So the crossover point can be 1 => swap the second dimension
    # There's little difference here, but let's do it consistently:
    cp = np.random.randint(1, 2)  # possible cross at dimension=1
    offspring1 = np.concatenate([parent1[:cp], parent2[cp:]])
    offspring2 = np.concatenate([parent2[:cp], parent1[cp:]])
    return offspring1, offspring2

def mutate(offspring, mutation_rate=0.01):
    """Mutate each gene with probability 'mutation_rate' by resetting to random in [0,1]."""
    for i in range(len(offspring)):
        if np.random.rand() < mutation_rate:
            offspring[i] = np.random.rand()
    return offspring

def evolve_population_ga(population, scores):
    """
    Perform one generation of GA:
      1) Selection (roulette wheel)
      2) Crossover (single-point)
      3) Mutation
    Returns the new population of the same size.
    """
    mating_pool = roulette_wheel_selection(population, scores)
    new_population = []
    # Create pairs
    for i in range(0, len(population), 2):
        parent1 = mating_pool[i]
        # if odd pop_size, handle boundary
        if i+1 < len(population):
            parent2 = mating_pool[i+1]
        else:
            parent2 = parent1

        # Crossover (always, since crossover_rate=1.0)
        offspring1, offspring2 = single_point_crossover(parent1, parent2)

        # Mutation
        offspring1 = mutate(offspring1, mutation_rate)
        offspring2 = mutate(offspring2, mutation_rate)

        new_population.append(offspring1)
        new_population.append(offspring2)

    new_population = np.array(new_population)[:len(population)]
    # Clip to [0,1]^2
    new_population = np.clip(new_population, 0, 1)
    return new_population

# ---------------------------
# Utility: Diversity and Improvement (for RPS-I)
# ---------------------------
def calculate_diversity(population):
    """
    Population diversity (α) as the sum of Euclidean distances from the mean position.
    """
    mean_pos = np.mean(population, axis=0)
    return np.sum(np.linalg.norm(population - mean_pos, axis=1))

def calculate_improvement_rate(prev_best, curr_best):
    """
    Improvement rate (β) as the relative change in the best (lowest) score.
    """
    return (prev_best - curr_best) / (curr_best + 1e-9)

# ---------------------------
# GA with/without RPS-I
# ---------------------------
def run_ga_and_capture_population(replace_random=False):
    """
    Run a GA for num_generations and capture population snapshots for visualization.

    - When replace_random = False, we run a standard GA.
    - When replace_random = True, we run an RPS-I-GA:
        * Compute α (diversity) and β (improvement rate)
        * Combine them into γ = 0.5*(α/α_max) + 0.5*(β/β_max), clipped [0,1]
        * Re-initialize N_regen = floor((1 - γ)*(pop_size - 1)) individuals,
          preserving the current best individual.
    """

    # Initialize population in [0,1]^2
    population = np.random.rand(pop_size, 2)

    # Evaluate initial scores
    scores = np.array([random_function(*ind) for ind in population])

    # Track best score
    best_index = np.argmin(scores)
    best_score = scores[best_index]

    # For RPS-I, track maxima of α, β, and previous best
    if replace_random:
        alpha_max = 1e-6
        beta_max = 1e-6
        prev_best = best_score

    # Dictionary to store snapshots
    population_snapshots = {0: population.copy()}

    # (Optional) track empty cells if you want (like in PSO code)
    empty_cells_per_iteration = []

    # GA loop
    for iteration in range(num_generations):
        # Occupancy grid (like in the PSO code, for “signature”):
        occupied_cells = np.zeros((grid_size, grid_size), dtype=bool)
        for pos in population:
            gx = int(pos[0] // cell_size)
            gy = int(pos[1] // cell_size)
            occupied_cells[gx, gy] = True
        num_empty_cells = np.sum(~occupied_cells)
        empty_cells_per_iteration.append(num_empty_cells)

        # Evolve population by GA
        new_population = evolve_population_ga(population, scores)

        # Evaluate new population
        new_scores = np.array([random_function(*ind) for ind in new_population])

        # Update best
        curr_best_index = np.argmin(new_scores)
        curr_best_score = new_scores[curr_best_index]

        # If we do RPS-I, calculate α, β, γ and partially re-initialize
        if replace_random:
            # α
            alpha = calculate_diversity(new_population)
            alpha_max = max(alpha_max, alpha)

            # β
            beta = calculate_improvement_rate(prev_best, curr_best_score)
            beta_max = max(beta_max, beta)

            # γ
            gamma = 0.5*(alpha/alpha_max) + 0.5*(beta/beta_max)
            gamma = np.clip(gamma, 0, 1)

            # number to reinitialize
            num_to_regenerate = int(np.floor((1 - gamma) * (pop_size - 1)))
            print(f"Iteration {iteration}: gamma = {gamma:.4f}, reinitialize count = {num_to_regenerate}")

            # preserve the best solution
            best_idx = curr_best_index
            indices = np.arange(pop_size)
            indices = np.delete(indices, best_idx)

            if num_to_regenerate > 0 and len(indices) > 0:
                regen_indices = np.random.choice(indices, min(num_to_regenerate, len(indices)), replace=False)
                for idx in regen_indices:
                    new_population[idx] = np.random.rand(2)

            # re-evaluate if reinit done
            reinit_scores = np.array([random_function(*ind) for ind in new_population])
            # check if best changed after re-init
            new_scores = reinit_scores
            new_best_index = np.argmin(new_scores)
            new_best_score = new_scores[new_best_index]
            prev_best = min(prev_best, new_best_score)  # update for next iteration
        else:
            # For standard GA, just keep track of best
            new_best_score = curr_best_score
            new_best_index = curr_best_index

        # Update population, scores, best
        population = new_population
        scores = new_scores
        best_index = new_best_index
        best_score = new_best_score

        # Store snapshot
        population_snapshots[iteration + 1] = population.copy()

    return empty_cells_per_iteration, population_snapshots

# ---------------------------
# Run GA for Both Versions
# ---------------------------
# 1) Standard GA (without RPS-I)
_, population_snapshots_ga = run_ga_and_capture_population(replace_random=False)

# 2) RPS-I-GA (with partial re-initialization)
_, population_snapshots_rpsiga = run_ga_and_capture_population(replace_random=True)

# ---------------------------
# Visualization
# ---------------------------
for generation in range(num_generations + 1):
    fig, axs = plt.subplots(1, 2, figsize=(12, 6))

    # Standard GA visualization
    axs[0].scatter(population_snapshots_ga[generation][:, 0],
                   population_snapshots_ga[generation][:, 1],
                   c="black", s=10, alpha=1.0)
    axs[0].set_title("GA - Generation: {}".format(generation), fontsize=20)
    axs[0].set_xlim(0, 1)
    axs[0].set_ylim(0, 1)
    axs[0].set_xlabel("X", fontsize=15)
    axs[0].set_ylabel("Y", fontsize=15)
    axs[0].tick_params(axis='both', labelsize=15)
    for i in range(1, grid_size):
        axs[0].axhline(i * cell_size, color='gray', linestyle='-', linewidth=0.5)
        axs[0].axvline(i * cell_size, color='gray', linestyle='-', linewidth=0.5)
    axs[0].grid(False)

    # RPS-I-GA visualization
    axs[1].scatter(population_snapshots_rpsiga[generation][:, 0],
                   population_snapshots_rpsiga[generation][:, 1],
                   c="black", s=10, alpha=1.0)
    axs[1].set_title("RPS-I-GA - Generation: {}".format(generation), fontsize=20)
    axs[1].set_xlim(0, 1)
    axs[1].set_ylim(0, 1)
    axs[1].set_xlabel("X", fontsize=15)
    axs[1].set_ylabel("Y", fontsize=15)
    axs[1].tick_params(axis='both', labelsize=15)
    for i in range(1, grid_size):
        axs[1].axhline(i * cell_size, color='gray', linestyle='-', linewidth=0.5)
        axs[1].axvline(i * cell_size, color='gray', linestyle='-', linewidth=0.5)
    axs[1].grid(False)

    plt.tight_layout()
    plt.show()
