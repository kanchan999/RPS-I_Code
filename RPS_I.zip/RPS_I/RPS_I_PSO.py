# Code for Structural Bias Determination in PSO and RPS-I-PSO Using the Generalized Signature Test
# Paper title: Regenerative Population Strategy-I: A Dynamic Methodology to Mitigate
#              Structural Bias in Metaheuristic Algorithms)
# Author: Kanchan Rajwar
# For assistance, contact: kanchanrajwar1519@gmail.com
#=======================================================================================================================
#=======================================================================================================================
import numpy as np
import random
import matplotlib.pyplot as plt
import matplotlib.patches as patches
#=======================================================================================================================
# PSO Parameters for velocity limits and acceleration coefficients
c1 = 2  # Cognitive (particle) weight
c2 = 2  # Social (swarm) weight
v_max = 1.0  # Maximum velocity
#=======================================================================================================================
def initialize_swarm(pop_size, dimensions, bounds=(0, 1)):
    """Initialize particles' positions and velocities within bounds."""
    positions = np.random.uniform(bounds[0], bounds[1], (pop_size, dimensions))
    velocities = np.random.uniform(-v_max, v_max, (pop_size, dimensions))
    return positions, velocities
#=======================================================================================================================
def objective_function(solution):
    """Uniformly random objective function as per the study."""
    return np.random.uniform(0, 1)
#=======================================================================================================================
def calculate_population_diversity(population):
    """
    Calculate diversity (α) as the sum of Euclidean distances from the mean position.
    A higher value indicates a more spread-out (diverse) population.
    """
    mean_position = np.mean(population, axis=0)
    diversity = np.sum([np.linalg.norm(ind - mean_position) for ind in population])
    return diversity
#=======================================================================================================================
def calculate_improvement_rate(fitness_best_prev, fitness_best_current):
    """
    Calculate improvement rate (β) as the relative change in the best fitness.
    A higher value indicates faster convergence.
    """
    return (fitness_best_prev - fitness_best_current) / (fitness_best_current + 1e-9)  # Avoid division by zero
#=======================================================================================================================
def calculate_gamma(alpha, alpha_max, beta, beta_max, w_alpha=0.5, w_beta=0.5):
    """
    Calculate the combined score γ as a weighted sum of the normalized diversity and improvement rate.
    γ is clipped to the range [0, 1].
    """
    # Update maximums if current metrics exceed the previous maximums
    alpha_max = max(alpha_max, alpha)
    beta_max = max(beta_max, beta)
    gamma = w_alpha * (alpha / alpha_max) + w_beta * (beta / beta_max)
    gamma = np.clip(gamma, 0, 1)
    return gamma, alpha_max, beta_max
#=======================================================================================================================
def apply_rps_i(population, gamma, bounds=(0, 1), global_best_index=None, print_info=False):
    """
    Apply RPS-I by regenerating a subset of the population based on γ.
    The number of individuals to regenerate is given by:
       N_regen = floor((1 - γ) * (P - 1))
    The best solution (specified by global_best_index) is preserved.
    """
    N = len(population)
    num_to_regenerate = int(np.floor((1 - gamma) * (N - 1)))

    # Build a list of indices excluding the global best
    indices = np.arange(N)
    if global_best_index is not None:
        indices = np.delete(indices, global_best_index)

    regen_indices = np.array([])
    if num_to_regenerate > 0 and len(indices) > 0:
        regen_indices = np.random.choice(indices, min(num_to_regenerate, len(indices)), replace=False)
        if print_info:
            print(f"    Regenerating particles at indices: {regen_indices}")
        for i in regen_indices:
            population[i] = np.random.uniform(bounds[0], bounds[1], population.shape[1])
    return population
#=======================================================================================================================
def calculate_ssf(population, dimensions, grid_cells=8):
    """
    Calculate the Signature Factor (SSF) based on the density of the population in a grid.
    This metric is based on the ratio of empty hypercubes to the total number of hypercubes.
    """
    grid_size = grid_cells
    grid = np.zeros((grid_size,) * dimensions)
    for individual in population:
        indices = tuple((individual * grid_size).astype(int) % grid_size)
        grid[indices] += 1
    empty_hypercubes = np.sum(grid == 0)
    return float(empty_hypercubes / (grid_size ** dimensions))  # Normalized by total cell count
#=======================================================================================================================
def standard_pso(pop_size, dimensions, max_generations=100, bounds=(0, 1)):
    """Standard PSO implementation without RPS-I."""
    # Inertia weight parameters for linear reduction
    w_max = 0.9
    w_min = 0.1

    positions, velocities = initialize_swarm(pop_size, dimensions, bounds)
    personal_best_positions = positions.copy()
    personal_best_scores = np.array([objective_function(ind) for ind in positions])
    global_best_index = np.argmin(personal_best_scores)
    global_best_position = personal_best_positions[global_best_index]
    global_best_score = np.min(personal_best_scores)
    ssf_values = []

    for generation in range(max_generations):
        # Compute inertia weight linearly reduced from 0.9 to 0.1
        w_t = w_max - (w_max - w_min) * generation / (max_generations - 1)

        # Evaluate fitness for each particle
        scores = np.array([objective_function(ind) for ind in positions])

        # Update personal bests
        improved = scores < personal_best_scores
        personal_best_positions[improved] = positions[improved]
        personal_best_scores[improved] = scores[improved]

        # Update global best
        if np.min(scores) < global_best_score:
            global_best_index = np.argmin(scores)
            global_best_position = positions[global_best_index]
            global_best_score = np.min(scores)

        # Record SSF value before velocity update (for standard PSO, no regeneration step)
        ssf_values.append(calculate_ssf(positions, dimensions))

        # Update velocities and positions for each particle
        for i in range(pop_size):
            r1, r2 = np.random.rand(dimensions), np.random.rand(dimensions)
            cognitive = c1 * r1 * (personal_best_positions[i] - positions[i])
            social = c2 * r2 * (global_best_position - positions[i])
            velocities[i] = w_t * velocities[i] + cognitive + social
            velocities[i] = np.clip(velocities[i], -v_max, v_max)
            positions[i] += velocities[i]
            positions[i] = np.clip(positions[i], bounds[0], bounds[1])
    return ssf_values
#=======================================================================================================================
def rps_i_pso(pop_size, dimensions, max_generations=100, bounds=(0, 1)):
    """PSO implementation with RPS-I applied at each generation."""
    # Inertia weight parameters for linear reduction
    w_max = 0.9
    w_min = 0.1

    positions, velocities = initialize_swarm(pop_size, dimensions, bounds)
    personal_best_positions = positions.copy()
    personal_best_scores = np.array([objective_function(ind) for ind in positions])
    global_best_index = np.argmin(personal_best_scores)
    global_best_position = personal_best_positions[global_best_index]
    global_best_score = np.min(personal_best_scores)
    ssf_values = []

    # Initialize RPS-I parameters
    alpha_max, beta_max = 1e-6, 1e-6  # Start with small values to avoid division by zero
    fitness_best_prev = global_best_score

    for generation in range(max_generations):
        # Compute inertia weight linearly reduced from 0.9 to 0.1
        w_t = w_max - (w_max - w_min) * generation / (max_generations - 1)

        # Evaluate fitness for each particle
        scores = np.array([objective_function(ind) for ind in positions])

        # Update personal bests
        improved = scores < personal_best_scores
        personal_best_positions[improved] = positions[improved]
        personal_best_scores[improved] = scores[improved]

        # Update global best
        if np.min(scores) < global_best_score:
            global_best_index = np.argmin(scores)
            global_best_position = positions[global_best_index]
            global_best_score = np.min(scores)

        # Calculate RPS-I metrics: population diversity (α) and improvement rate (β)
        alpha = calculate_population_diversity(positions)
        beta = calculate_improvement_rate(fitness_best_prev, global_best_score)
        gamma, alpha_max, beta_max = calculate_gamma(alpha, alpha_max, beta, beta_max)

        # Compute the number of particles to reinitialize
        num_to_regenerate = int(np.floor((1 - gamma) * (len(positions) - 1)))
        print(
            "------------------------------------------------------------------------------------------------------------------")

        print(f"Generation {generation}: gamma = {gamma:.4f}, reinitialize count = {num_to_regenerate}")


        # Apply RPS-I: regenerate a portion of the population, excluding the best solution
        positions = apply_rps_i(positions, gamma, bounds, global_best_index=global_best_index, print_info=True)

        # Measure and record SSF after reinitialization
        ssf_after_reinit = calculate_ssf(positions, dimensions)
        print(f"    SSF : {ssf_after_reinit:.4f}")
        ssf_values.append(ssf_after_reinit)

        # Update velocities and positions for each particle
        for i in range(pop_size):
            r1, r2 = np.random.rand(dimensions), np.random.rand(dimensions)
            cognitive = c1 * r1 * (personal_best_positions[i] - positions[i])
            social = c2 * r2 * (global_best_position - positions[i])
            velocities[i] = w_t * velocities[i] + cognitive + social
            velocities[i] = np.clip(velocities[i], -v_max, v_max)
            positions[i] += velocities[i]
            positions[i] = np.clip(positions[i], bounds[0], bounds[1])

        # Update previous best fitness for the next generation's improvement rate calculation
        fitness_best_prev = global_best_score

    return ssf_values
#=======================================================================================================================
if __name__ == "__main__":
    # Parameters for running the algorithms
    dimensions = 3  # Dimensionality of the problem ([0,1]^3)
    pop_size = 512  # Population size
    max_generations = 100  # Number of generations
    bounds = (0, 1)

    # Run standard PSO
    ssf_values_pso = standard_pso(pop_size, dimensions, max_generations, bounds)

    # Run RPS-I PSO
    ssf_values_rps_pso = rps_i_pso(pop_size, dimensions, max_generations, bounds)
    print(
        "------------------------------------------------------------------------------------------------------------------")

    # Print SSF comparison for both algorithms at selected iterations
    print("SSF values for particular iterations of Standard PSO:")
    print(f"Iteration 0:  {ssf_values_pso[0]:.4f}")
    print(f"Iteration 24: {ssf_values_pso[24]:.4f}")
    print(f"Iteration 49: {ssf_values_pso[49]:.4f}")
    print(f"Iteration 74: {ssf_values_pso[74]:.4f}")
    print(f"Iteration 99: {ssf_values_pso[99]:.4f}")

    print(
        "------------------------------------------------------------------------------------------------------------------")

    print("\nSSF values for particular iterations of RPS-I PSO:")
    print(f"Iteration 0:  {ssf_values_rps_pso[0]:.4f}")
    print(f"Iteration 24: {ssf_values_rps_pso[24]:.4f}")
    print(f"Iteration 49: {ssf_values_rps_pso[49]:.4f}")
    print(f"Iteration 74: {ssf_values_rps_pso[74]:.4f}")
    print(f"Iteration 99: {ssf_values_rps_pso[99]:.4f}")

    # Plot the results
    plt.figure(figsize=(10, 6))
    plt.plot(ssf_values_pso, label="PSO", marker='o', markersize=4, linewidth=2)
    plt.plot(ssf_values_rps_pso, label="RPS-I-PSO", marker='s', markersize=4, linewidth=2)
    plt.legend(fontsize=16)
    plt.xlim(0, max_generations)
    plt.ylim(0.3, 1)
    plt.xlabel("Iteration", fontsize=16)
    plt.ylabel("Signature Factor (\u03B7)", fontsize=16)
    plt.grid(True)

    # Add a thick border around the plot area
    import matplotlib.patches as patches

    border_thickness = 5
    plt.gca().add_patch(
        patches.Rectangle(
            (0, 0), 1, 1, transform=plt.gca().transAxes,
            linewidth=border_thickness, edgecolor='black', facecolor='none'
        )
    )

    plt.show()
    print(
        "------------------------------------------------------------------------------------------------------------------")

#=======================================================================================================================
#=======================================================================================================================
