# Code for Structural Bias Determination in DE and RPS-I-DE Using the Generalized Signature Test
# Paper title: Regenerative Population Strategy-I: A Dynamic Methodology to Mitigate
#              Structural Bias in Metaheuristic Algorithms)
# Author: Kanchan Rajwar
# For assistance, contact: kanchanrajwar1519@gmail.com
# ======================================================================================================================
# ======================================================================================================================
import numpy as np
import random
import matplotlib.pyplot as plt
import matplotlib.patches as patches

# ======================================================================================================================
# DE Parameters
F = 0.5          # Scaling factor for differential mutation
CR = 0.5         # Crossover rate for binomial crossover
# ======================================================================================================================

def objective_function(solution):
    """
    Uniformly random objective function as per the study.
    The returned value is in [0,1], and we want to MINIMIZE it.
    """
    return np.random.uniform(0, 1)

# ======================================================================================================================
def initialize_population(pop_size, dimensions, bounds=(0,1)):
    """
    Initialize the population in [0,1]^dimensions for each individual.
    """
    return np.random.uniform(bounds[0], bounds[1], (pop_size, dimensions))

# ======================================================================================================================
def calculate_population_diversity(population):
    """
    Calculate diversity (alpha) as the sum of Euclidean distances from the mean position.
    A higher value indicates a more spread-out (diverse) population.
    """
    mean_position = np.mean(population, axis=0)
    diversity = np.sum([np.linalg.norm(ind - mean_position) for ind in population])
    return diversity

# ======================================================================================================================
def calculate_improvement_rate(fitness_best_prev, fitness_best_current):
    """
    Calculate improvement rate (beta) as the relative change in the best (lowest) fitness.
    A higher value indicates faster convergence.
    """
    return (fitness_best_prev - fitness_best_current) / (fitness_best_current + 1e-9)  # Avoid division by zero

# ======================================================================================================================
def calculate_gamma(alpha, alpha_max, beta, beta_max, w_alpha=0.5, w_beta=0.5):
    """
    Calculate the combined score gamma as a weighted sum of the normalized diversity (alpha/alpha_max)
    and improvement rate (beta/beta_max). gamma is clipped to [0,1].
    """
    alpha_max = max(alpha_max, alpha)
    beta_max = max(beta_max, beta)
    gamma = w_alpha * (alpha / alpha_max) + w_beta * (beta / beta_max)
    gamma = np.clip(gamma, 0, 1)
    return gamma, alpha_max, beta_max

# ======================================================================================================================
def calculate_ssf(population, dimensions, grid_cells=8):
    """
    Calculate the Signature Factor (SSF) based on population density in a grid.
    This metric is the ratio of empty hypercubes to the total number of hypercubes.
    """
    grid_size = grid_cells
    grid = np.zeros((grid_size,) * dimensions)
    for individual in population:
        # Convert each coordinate to an integer index in the grid
        indices = tuple((individual * grid_size).astype(int) % grid_size)
        grid[indices] += 1
    empty_hypercubes = np.sum(grid == 0)
    return float(empty_hypercubes / (grid_size ** dimensions))  # normalized by total cell count

# ======================================================================================================================
def apply_rps_i(population, gamma, best_index=None, bounds=(0,1), print_info=False):
    """
    Apply RPS-I by regenerating a subset of the population based on gamma.
    The number of individuals to regenerate is:
       N_regen = floor((1 - gamma) * (P - 1))
    The best solution (best_index) is preserved.
    """
    N = len(population)
    num_to_regenerate = int(np.floor((1 - gamma) * (N - 1)))

    # Exclude the best solution from regeneration
    indices = np.arange(N)
    if best_index is not None:
        indices = np.delete(indices, best_index)

    if num_to_regenerate > 0 and len(indices) > 0:
        regen_indices = np.random.choice(indices, min(num_to_regenerate, len(indices)), replace=False)
        if print_info:
            print(f"    Regenerating individuals at indices: {regen_indices}")
        for i in regen_indices:
            population[i] = np.random.uniform(bounds[0], bounds[1], population.shape[1])

    return population

# ======================================================================================================================
# DE Core Operators
# ======================================================================================================================
def mutate_and_crossover(population, i, best_index, bounds=(0,1)):
    """
    DE/rand/1/bin strategy:
      1) Select three distinct random indices (r1, r2, r3) all different from i.
      2) Generate donor vector: V = X[r1] + F * (X[r2] - X[r3])
      3) Perform binomial crossover with CR to produce trial vector U.
    """
    pop_size, dimensions = population.shape

    # Choose three distinct random indices, all different from i
    indices = list(range(pop_size))
    indices.remove(i)
    r1, r2, r3 = np.random.choice(indices, 3, replace=False)

    # 1) Donor vector
    donor = population[r1] + F * (population[r2] - population[r3])

    # Keep donor within bounds
    donor = np.clip(donor, bounds[0], bounds[1])

    # 2) Binomial crossover
    trial = np.copy(population[i])
    rand_dim = np.random.randint(dimensions)  # At least one dimension must come from donor
    for d in range(dimensions):
        if np.random.rand() < CR or d == rand_dim:
            trial[d] = donor[d]

    # Also clip trial within the bounds
    trial = np.clip(trial, bounds[0], bounds[1])

    return trial

# ======================================================================================================================
def evolve_population_de(population, scores, bounds=(0,1)):
    """
    Perform one iteration (one generation) of DE:
      - For each individual i:
        - Generate trial vector (mutation + crossover)
        - Evaluate trial
        - Greedy selection: if trial is better, replace
    Returns the updated population and updated scores.
    """
    pop_size, dimensions = population.shape
    new_population = np.copy(population)
    new_scores = np.copy(scores)

    for i in range(pop_size):
        trial = mutate_and_crossover(population, i, np.argmin(scores), bounds=bounds)

        # Evaluate trial
        trial_score = objective_function(trial)

        # Greedy selection
        if trial_score < new_scores[i]:
            new_population[i] = trial
            new_scores[i] = trial_score

    return new_population, new_scores

# ======================================================================================================================
# 1. Standard DE (Without RPS-I)
# ======================================================================================================================
def standard_de(pop_size, dimensions, max_generations=100, bounds=(0,1)):
    """
    Standard DE algorithm:
      - Initialize population
      - Evaluate
      - For each generation:
        - Evolve population (mutation, crossover, selection)
        - Compute SSF
    """
    # 1) Initialize
    population = initialize_population(pop_size, dimensions, bounds)

    # 2) Evaluate
    scores = np.array([objective_function(ind) for ind in population])

    ssf_values = []

    # 3) Main loop
    for gen in range(max_generations):
        # Calculate SSF before evolving
        ssf_values.append(calculate_ssf(population, dimensions))

        # Evolve population
        population, scores = evolve_population_de(population, scores, bounds=bounds)

    return ssf_values

# ======================================================================================================================
# 2. RPS-I-DE
# ======================================================================================================================
def rps_i_de(pop_size, dimensions, max_generations=100, bounds=(0,1)):
    """
    DE with RPS-I applied each generation:
      - Initialize population
      - Evaluate -> get alpha, beta, gamma
      - Regenerate a portion of population based on gamma
      - Evolve (DE mutation, crossover, selection)
    """
    # 1) Initialize
    population = initialize_population(pop_size, dimensions, bounds)

    # 2) Evaluate initial population
    scores = np.array([objective_function(ind) for ind in population])
    best_index = np.argmin(scores)
    best_score = scores[best_index]

    # RPS-I tracking
    alpha_max, beta_max = 1e-6, 1e-6
    fitness_best_prev = best_score

    ssf_values = []

    # 3) Main loop
    for gen in range(max_generations):
        # Recompute best
        best_index = np.argmin(scores)
        best_score = scores[best_index]

        # Calculate alpha, beta, gamma
        alpha = calculate_population_diversity(population)
        beta = calculate_improvement_rate(fitness_best_prev, best_score)
        gamma, alpha_max, beta_max = calculate_gamma(alpha, alpha_max, beta, beta_max)

        # Apply RPS-I
        num_to_regen = int(np.floor((1 - gamma) * (len(population) - 1)))
        print("------------------------------------------------------------------------------------------------------------------")
        print(f"Generation {gen}: gamma = {gamma:.4f}, reinitialize count = {num_to_regen}")

        population = apply_rps_i(population, gamma, best_index=best_index, bounds=bounds, print_info=True)

        # Calculate SSF after reinit
        ssf_after_reinit = calculate_ssf(population, dimensions)
        print(f"    SSF : {ssf_after_reinit:.4f}")
        ssf_values.append(ssf_after_reinit)

        # DE Evolution
        population, scores = evolve_population_de(population, scores, bounds=bounds)

        # Update for next iteration
        fitness_best_prev = best_score

    return ssf_values

# ======================================================================================================================
# Main Execution
# ======================================================================================================================
if __name__ == "__main__":
    # Parameters
    dimensions = 3        # Dimensionality of the problem ([0,1]^3)
    pop_size = 512        # Population size
    max_generations = 100 # Number of generations
    bounds = (0,1)

    # Run standard DE
    ssf_values_de = standard_de(pop_size, dimensions, max_generations, bounds)

    # Run RPS-I-DE
    ssf_values_rps_de = rps_i_de(pop_size, dimensions, max_generations, bounds)

    print("------------------------------------------------------------------------------------------------------------------")

    # Print SSF comparison for selected iterations
    print("SSF values for particular iterations of Standard DE:")
    print(f"Iteration 0:  {ssf_values_de[0]:.4f}")
    print(f"Iteration 24: {ssf_values_de[24]:.4f}")
    print(f"Iteration 49: {ssf_values_de[49]:.4f}")
    print(f"Iteration 74: {ssf_values_de[74]:.4f}")
    print(f"Iteration 99: {ssf_values_de[99]:.4f}")

    print("------------------------------------------------------------------------------------------------------------------")

    print("\nSSF values for particular iterations of RPS-I DE:")
    print(f"Iteration 0:  {ssf_values_rps_de[0]:.4f}")
    print(f"Iteration 24: {ssf_values_rps_de[24]:.4f}")
    print(f"Iteration 49: {ssf_values_rps_de[49]:.4f}")
    print(f"Iteration 74: {ssf_values_rps_de[74]:.4f}")
    print(f"Iteration 99: {ssf_values_rps_de[99]:.4f}")

    # Plot the results
    plt.figure(figsize=(10, 6))
    plt.plot(ssf_values_de, label="DE", marker='o', markersize=4, linewidth=2)
    plt.plot(ssf_values_rps_de, label="RPS-I-DE", marker='s', markersize=4, linewidth=2)
    plt.legend(fontsize=16)
    plt.xlim(0, max_generations)
    plt.ylim(0.3, 1)
    plt.xlabel("Iteration", fontsize=16)
    plt.ylabel("Signature Factor (η)", fontsize=16)
    plt.grid(True)

    # Add a thick border around the plot area
    border_thickness = 5
    plt.gca().add_patch(
        patches.Rectangle(
            (0, 0), 1, 1, transform=plt.gca().transAxes,
            linewidth=border_thickness, edgecolor='black', facecolor='none'
        )
    )

    plt.show()
    print("------------------------------------------------------------------------------------------------------------------")
# ======================================================================================================================
# ======================================================================================================================
