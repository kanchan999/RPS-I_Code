# Code for Structural Bias Determination in GA and RPS-I-GA Using the Generalized Signature Test
# Paper title: Regenerative Population Strategy-I: A Dynamic Methodology to Mitigate
#              Structural Bias in Metaheuristic Algorithms)
# Author: Kanchan Rajwar
# For assistance, contact: kanchanrajwar1519@gmail.com
# ======================================================================================================================
# ======================================================================================================================

import numpy as np
import random
import matplotlib.pyplot as plt
import matplotlib.patches as patches

# ======================================================================================================================
# GA Parameters
crossover_rate = 1.0       # Probability of performing crossover on selected parents
mutation_rate = 0.01       # Probability of mutating each gene
# ======================================================================================================================

def objective_function(solution):
    """
    Uniformly random objective function as per the study.
    For consistency with the PSO code, we consider a 'score' we want to MINIMIZE.
    The returned value is in [0,1].
    """
    return np.random.uniform(0, 1)

# ======================================================================================================================
def calculate_population_diversity(population):
    """
    Calculate diversity (alpha) as the sum of Euclidean distances from the mean position.
    A higher value indicates a more spread-out (diverse) population.
    """
    mean_position = np.mean(population, axis=0)
    diversity = np.sum([np.linalg.norm(ind - mean_position) for ind in population])
    return diversity

# ======================================================================================================================
def calculate_improvement_rate(fitness_best_prev, fitness_best_current):
    """
    Calculate improvement rate (beta) as the relative change in the best (lowest) fitness.
    A higher value indicates faster convergence.
    """
    return (fitness_best_prev - fitness_best_current) / (fitness_best_current + 1e-9)  # Avoid division by zero

# ======================================================================================================================
def calculate_gamma(alpha, alpha_max, beta, beta_max, w_alpha=0.5, w_beta=0.5):
    """
    Calculate the combined score gamma as a weighted sum of the normalized diversity and improvement rate.
    gamma is clipped to the range [0, 1].
    """
    # Update maximums if current metrics exceed the previous maximums
    alpha_max = max(alpha_max, alpha)
    beta_max = max(beta_max, beta)
    gamma = w_alpha * (alpha / alpha_max) + w_beta * (beta / beta_max)
    gamma = np.clip(gamma, 0, 1)
    return gamma, alpha_max, beta_max

# ======================================================================================================================
def apply_rps_i(population, gamma, best_index=None, bounds=(0,1), print_info=False):
    """
    Apply RPS-I by regenerating a subset of the population based on gamma.
    The number of individuals to regenerate is:
       N_regen = floor((1 - gamma) * (P - 1))
    The best solution (specified by best_index) is preserved.
    """
    N = len(population)
    num_to_regenerate = int(np.floor((1 - gamma) * (N - 1)))

    # Build a list of indices excluding the best solution
    indices = np.arange(N)
    if best_index is not None:
        indices = np.delete(indices, best_index)

    if num_to_regenerate > 0 and len(indices) > 0:
        regen_indices = np.random.choice(indices, min(num_to_regenerate, len(indices)), replace=False)
        if print_info:
            print(f"    Regenerating individuals at indices: {regen_indices}")
        for i in regen_indices:
            population[i] = np.random.uniform(bounds[0], bounds[1], population.shape[1])

    return population

# ======================================================================================================================
def calculate_ssf(population, dimensions, grid_cells=8):
    """
    Calculate the Signature Factor (SSF) based on the density of the population in a grid.
    This metric is the ratio of empty hypercubes to the total number of hypercubes.
    """
    grid_size = grid_cells
    grid = np.zeros((grid_size,) * dimensions)
    for individual in population:
        # Convert each coordinate to an integer index in the grid
        indices = tuple((individual * grid_size).astype(int) % grid_size)
        grid[indices] += 1
    empty_hypercubes = np.sum(grid == 0)
    return float(empty_hypercubes / (grid_size ** dimensions))  # normalized by total cell count

# ======================================================================================================================
# GA Operators
# ======================================================================================================================
def initialize_population(pop_size, dimensions, bounds=(0,1)):
    """
    Initialize the population in [0,1]^dimensions for each individual.
    """
    return np.random.uniform(bounds[0], bounds[1], (pop_size, dimensions))

# ------------------------------------------------------------------------
def roulette_wheel_selection(population, scores, pop_size):
    """
    Perform roulette-wheel selection.
    Since we want to MINIMIZE 'scores', we convert to 'fitness = 1 - score' for selection (scores in [0,1]).
    If 'score' is small, 'fitness' is large -> higher chance of selection.
    """
    fitness = 1.0 - scores  # Convert cost to fitness
    total_fitness = np.sum(fitness)

    if total_fitness <= 1e-12:
        # If total_fitness is extremely small (or zero), fallback to random selection
        selected_indices = np.random.randint(0, len(population), size=pop_size)
        return population[selected_indices]

    # Create the cumulative distribution
    cdf = np.cumsum(fitness / total_fitness)

    new_pop = []
    for _ in range(pop_size):
        r = random.random()
        idx = np.searchsorted(cdf, r)
        new_pop.append(population[idx])

    return np.array(new_pop)

# ------------------------------------------------------------------------
def single_point_crossover(parent1, parent2):
    """
    Single-point crossover (crossover_rate = 1 means always cross).
    For real-coded, we treat the solution as a 1D array of 'dimensions' genes.
    We pick one crossover point, then exchange the segments.
    """
    d = len(parent1)
    if d == 1:
        # Single dimension -> no real 'split'; just return parents
        return np.copy(parent1), np.copy(parent2)

    cp = np.random.randint(1, d)  # crossover point between [1..d-1]
    offspring1 = np.concatenate([parent1[:cp], parent2[cp:]])
    offspring2 = np.concatenate([parent2[:cp], parent1[cp:]])
    return offspring1, offspring2

# ------------------------------------------------------------------------
def mutation(offspring, mutation_rate=0.01, bounds=(0,1)):
    """
    Mutate each gene with probability 'mutation_rate' by resetting it to a random value in [0,1].
    """
    for i in range(len(offspring)):
        if random.random() < mutation_rate:
            offspring[i] = np.random.uniform(bounds[0], bounds[1])
    return offspring

# ------------------------------------------------------------------------
def evolve_population_ga(population, scores, pop_size, bounds=(0,1)):
    """
    Perform a single generation of standard GA operations:
      - Roulette-wheel selection
      - Single-point crossover (with probability = 1.0)
      - Mutation (with probability = 0.01 per gene)
    Returns the new population of the same size.
    """
    # Selection
    mating_pool = roulette_wheel_selection(population, scores, pop_size)

    new_population = []
    # Recombine individuals in pairs
    for i in range(0, pop_size, 2):
        parent1 = mating_pool[i]
        if i+1 < pop_size:
            parent2 = mating_pool[i+1]
        else:
            # Odd pop_size -> clone parent1
            parent2 = parent1

        # Crossover (always, since crossover_rate=1.0)
        offspring1, offspring2 = single_point_crossover(parent1, parent2)

        # Mutation
        offspring1 = mutation(offspring1, mutation_rate)
        offspring2 = mutation(offspring2, mutation_rate)

        new_population.append(offspring1)
        new_population.append(offspring2)

    new_population = np.array(new_population)[:pop_size]  # ensure size is pop_size
    return new_population

# ======================================================================================================================
# Standard GA (Without RPS-I)
# ======================================================================================================================
def standard_ga(pop_size, dimensions, max_generations=100, bounds=(0,1)):
    """
    Standard GA:
     - Initialize population
     - Evaluate
     - For each generation:
       - Evolve population (selection, crossover, mutation)
       - Compute SSF
    """
    # Initialize population
    population = initialize_population(pop_size, dimensions, bounds)
    ssf_values = []

    # Track best solution (for reference only)
    scores = np.array([objective_function(ind) for ind in population])
    best_index = np.argmin(scores)
    best_score = scores[best_index]

    for gen in range(max_generations):
        # Evaluate population
        scores = np.array([objective_function(ind) for ind in population])

        # Track best
        curr_best_index = np.argmin(scores)
        curr_best_score = scores[curr_best_index]
        if curr_best_score < best_score:
            best_score = curr_best_score
            best_index = curr_best_index

        # Calculate SSF
        ssf_values.append(calculate_ssf(population, dimensions))

        # Evolve population
        population = evolve_population_ga(population, scores, pop_size, bounds)

    return ssf_values

# ======================================================================================================================
# RPS-I-GA
# ======================================================================================================================
def rps_i_ga(pop_size, dimensions, max_generations=100, bounds=(0,1)):
    """
    GA with RPS-I applied each generation:
     - Initialize population
     - Evaluate -> get alpha, beta, gamma
     - Regenerate a portion of population based on gamma
     - Evolve (selection, crossover, mutation)
    """
    # Initialize population
    population = initialize_population(pop_size, dimensions, bounds)

    # Evaluate initial population
    scores = np.array([objective_function(ind) for ind in population])
    best_index = np.argmin(scores)
    best_score = scores[best_index]

    # For RPS-I metrics
    alpha_max, beta_max = 1e-6, 1e-6
    fitness_best_prev = best_score

    ssf_values = []

    for gen in range(max_generations):
        # Re-evaluate population
        scores = np.array([objective_function(ind) for ind in population])

        # Update best
        curr_best_index = np.argmin(scores)
        curr_best_score = scores[curr_best_index]
        if curr_best_score < best_score:
            best_score = curr_best_score
            best_index = curr_best_index

        # Calculate alpha, beta, gamma
        alpha = calculate_population_diversity(population)
        beta = calculate_improvement_rate(fitness_best_prev, best_score)
        gamma, alpha_max, beta_max = calculate_gamma(alpha, alpha_max, beta, beta_max)

        # Apply RPS-I
        num_to_regen = int(np.floor((1 - gamma) * (len(population) - 1)))
        print("------------------------------------------------------------------------------------------------------------------")
        print(f"Generation {gen}: gamma = {gamma:.4f}, reinitialize count = {num_to_regen}")

        population = apply_rps_i(population, gamma, best_index, bounds, print_info=True)

        # Calculate SSF after reinitialization
        ssf_after_reinit = calculate_ssf(population, dimensions)
        print(f"    SSF : {ssf_after_reinit:.4f}")
        ssf_values.append(ssf_after_reinit)

        # Evolve population (GA operators)
        population = evolve_population_ga(population, scores, pop_size, bounds)

        # Update for the next iteration
        fitness_best_prev = best_score

    return ssf_values

# ======================================================================================================================
# Main Execution
# ======================================================================================================================
if __name__ == "__main__":
    # Parameters for running the algorithms
    dimensions = 3     # Dimensionality of the problem ([0,1]^3)
    pop_size = 512     # Population size
    max_generations = 100  # Number of generations
    bounds = (0,1)

    # Run standard GA
    ssf_values_ga = standard_ga(pop_size, dimensions, max_generations, bounds)

    # Run RPS-I-GA
    ssf_values_rps_ga = rps_i_ga(pop_size, dimensions, max_generations, bounds)

    print("------------------------------------------------------------------------------------------------------------------")

    # Print SSF comparison for both algorithms at selected iterations
    print("SSF values for particular iterations of Standard GA:")
    print(f"Iteration 0:  {ssf_values_ga[0]:.4f}")
    print(f"Iteration 24: {ssf_values_ga[24]:.4f}")
    print(f"Iteration 49: {ssf_values_ga[49]:.4f}")
    print(f"Iteration 74: {ssf_values_ga[74]:.4f}")
    print(f"Iteration 99: {ssf_values_ga[99]:.4f}")

    print("------------------------------------------------------------------------------------------------------------------")

    print("\nSSF values for particular iterations of RPS-I GA:")
    print(f"Iteration 0:  {ssf_values_rps_ga[0]:.4f}")
    print(f"Iteration 24: {ssf_values_rps_ga[24]:.4f}")
    print(f"Iteration 49: {ssf_values_rps_ga[49]:.4f}")
    print(f"Iteration 74: {ssf_values_rps_ga[74]:.4f}")
    print(f"Iteration 99: {ssf_values_rps_ga[99]:.4f}")

    # Plot the results
    plt.figure(figsize=(10, 6))
    plt.plot(ssf_values_ga, label="GA", marker='o', markersize=4, linewidth=2)
    plt.plot(ssf_values_rps_ga, label="RPS-I-GA", marker='s', markersize=4, linewidth=2)
    plt.legend(fontsize=16)
    plt.xlim(0, max_generations)
    plt.ylim(0.3, 1)
    plt.xlabel("Iteration", fontsize=16)
    plt.ylabel("Signature Factor (η)", fontsize=16)
    plt.grid(True)

    # Add a thick border around the plot area
    border_thickness = 5
    plt.gca().add_patch(
        patches.Rectangle(
            (0, 0), 1, 1, transform=plt.gca().transAxes,
            linewidth=border_thickness, edgecolor='black', facecolor='none'
        )
    )

    plt.show()
    print("------------------------------------------------------------------------------------------------------------------")
# ======================================================================================================================
# ======================================================================================================================
