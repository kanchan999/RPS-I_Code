# Code for visualization (signature) of population in HHO and RPS-I-HHO (Figure 14)
# Paper title: Regenerative Population Strategy-I: A Dynamic Methodology to Mitigate
#              Structural Bias in Metaheuristic Algorithms)
# Author: Kanchan Rajwar
# For assistance, contact: kanchanrajwar1519@gmail.com
# ======================================================================================================================
# ======================================================================================================================

import numpy as np
import matplotlib.pyplot as plt

# 1) Random Objective Function
def random_function(x, y):
    """
    Returns a random value in [0,1], which we aim to MINIMIZE.
    """
    return np.random.rand()

# 2) Global Parameters
pop_size = 10000      # Number of hawks
num_generations = 10  # Number of iterations
grid_size = 100       # For visualization grid
cell_size = 1 / grid_size

# HHO specifics:
# "escape energy" E_0 changes from -1 -> +1 linearly across iterations.
# If |E_0| >= 1 => exploration.
# If |E_0| < 1 => exploitation (soft/hard besiege).

# ---------------------------
# Utility: Diversity & Improvement
# ---------------------------
def calculate_diversity(population):
    """
    Population diversity (alpha) as the sum of Euclidean distances from the mean position.
    """
    mean_pos = np.mean(population, axis=0)
    return np.sum(np.linalg.norm(population - mean_pos, axis=1))

def calculate_improvement_rate(prev_best, curr_best):
    """
    Improvement rate (beta) as the relative change in the best (lowest) score.
    """
    return (prev_best - curr_best) / (curr_best + 1e-9)

# ---------------------------
# One Iteration of Standard HHO
# ---------------------------
def hho_one_iteration(population, scores, iteration, max_iterations):
    """
    Perform one iteration of standard Harris Hawks Optimization in 2D:
      - 'escape energy' E_0 changes from -1 -> +1 linearly
      - If |E_0| >= 1 => exploration
      - If |E_0| < 1  => exploitation
    Returns updated population, scores.
    """
    pop_size, _ = population.shape
    # Identify best hawk (lowest score)
    best_idx = np.argmin(scores)
    best_score = scores[best_idx]
    best_pos = population[best_idx].copy()

    # E_0 from -1 at iteration=0 to +1 at iteration=(max_iterations-1)
    E_0 = -1.0 + 2.0 * (iteration / (max_iterations - 1))  # linear

    new_population = np.copy(population)
    new_scores     = np.copy(scores)

    for i in range(pop_size):
        current_pos = population[i]
        current_score = scores[i]

        r1 = np.random.rand()
        r2 = np.random.rand()

        if abs(E_0) >= 1:
            # Exploration phase
            # Randomly pick another hawk
            rand_idx = np.random.randint(pop_size)
            X_rand = population[rand_idx]
            q = np.random.rand()
            D_rand = abs(q * X_rand - current_pos)
            new_pos = X_rand - r1 * D_rand
        else:
            # Exploitation phase
            # Dist from best
            D_best = abs(r2 * best_pos - current_pos)
            # "Jump strength" factor
            L_J = 2.0 * (1 - r2)  # simplified jump factor

            # Probability switch for "soft" vs "hard" besiege
            if np.random.rand() < 0.5:
                # Soft besiege
                new_pos = best_pos - E_0 * D_best
            else:
                # Hard besiege
                new_pos = (best_pos - E_0 * D_best) - r1 * L_J * (D_best)

        # Clip to [0,1]^2
        new_pos = np.clip(new_pos, 0.0, 1.0)

        new_score = random_function(*new_pos)
        # Greedy update
        if new_score < new_scores[i]:
            new_population[i] = new_pos
            new_scores[i] = new_score

    return new_population, new_scores

# ---------------------------
# RPS-I Step
# ---------------------------
def apply_rps_i(population, scores, alpha_max, beta_max, prev_best):
    """
    1) Compute alpha (diversity), beta (improvement rate)
    2) Combine into gamma
    3) Reinitialize part of the population, preserving best
    """
    pop_size = len(population)
    curr_best_idx = np.argmin(scores)
    curr_best_score = scores[curr_best_idx]

    # alpha = diversity
    alpha = calculate_diversity(population)
    alpha_max = max(alpha_max, alpha)

    # beta = improvement
    beta = calculate_improvement_rate(prev_best, curr_best_score)
    beta_max = max(beta_max, beta)

    # gamma
    gamma = 0.5 * (alpha / alpha_max) + 0.5 * (beta / beta_max)
    gamma = np.clip(gamma, 0, 1)

    num_to_regen = int(np.floor((1 - gamma) * (pop_size - 1)))
    print(f"    gamma={gamma:.4f}, reinitialize={num_to_regen}")

    if num_to_regen > 0:
        # preserve best
        indices = np.arange(pop_size)
        indices = np.delete(indices, curr_best_idx)
        if len(indices) > 0:
            regen_indices = np.random.choice(indices, min(num_to_regen, len(indices)), replace=False)
            for idx in regen_indices:
                population[idx] = np.random.rand(2)
                scores[idx] = random_function(*population[idx])

    # update prev_best
    new_best_idx = np.argmin(scores)
    new_best_score = scores[new_best_idx]
    updated_prev_best = min(prev_best, new_best_score)

    return population, scores, alpha_max, beta_max, updated_prev_best

# ---------------------------
# Runner: Standard HHO vs. RPS-I-HHO
# ---------------------------
def run_hho_and_capture_population(replace_random=False):
    """
    Run Harris Hawks Optimization in 2D for num_generations, capturing snapshots.
    If replace_random=True, we do RPS-I-HHO:
      - Each iteration, do RPS-I first, then the standard HHO update
    """
    # Initialize population in [0,1]^2
    population = np.random.rand(pop_size, 2)
    scores = np.array([random_function(*pos) for pos in population])

    # Track best
    best_idx = np.argmin(scores)
    best_score = scores[best_idx]

    # For RPS-I
    if replace_random:
        alpha_max = 1e-6
        beta_max  = 1e-6
        prev_best = best_score

    # Dictionary for snapshots
    population_snapshots = {0: population.copy()}
    empty_cells_per_iteration = []

    for gen in range(num_generations):
        # Occupancy grid (for “signature”)
        occupied = np.zeros((grid_size, grid_size), dtype=bool)
        for pos in population:
            gx = int(pos[0] // cell_size)
            gy = int(pos[1] // cell_size)
            occupied[gx, gy] = True
        num_empty_cells = np.sum(~occupied)
        empty_cells_per_iteration.append(num_empty_cells)

        # If we have RPS-I, apply it first
        if replace_random:
            print(f"Generation {gen}:")
            population, scores, alpha_max, beta_max, prev_best = apply_rps_i(
                population, scores, alpha_max, beta_max, prev_best
            )

        # Standard HHO iteration
        population, scores = hho_one_iteration(population, scores, gen, num_generations)

        # Update best
        best_idx = np.argmin(scores)
        best_score = scores[best_idx]

        # Store snapshot
        population_snapshots[gen + 1] = population.copy()

    return empty_cells_per_iteration, population_snapshots

# ---------------------------
# Run Standard HHO and RPS-I-HHO
# ---------------------------
_, population_snapshots_hho    = run_hho_and_capture_population(replace_random=False)
_, population_snapshots_rpsihho = run_hho_and_capture_population(replace_random=True)

# ---------------------------
# Visualization of Snapshots
# ---------------------------
for generation in range(num_generations + 1):
    fig, axs = plt.subplots(1, 2, figsize=(12, 6))

    # Standard HHO
    axs[0].scatter(population_snapshots_hho[generation][:, 0],
                   population_snapshots_hho[generation][:, 1],
                   c="black", s=10, alpha=1.0)
    axs[0].set_title("HHO - Generation: {}".format(generation), fontsize=20)
    axs[0].set_xlim(0, 1)
    axs[0].set_ylim(0, 1)
    axs[0].set_xlabel("X", fontsize=15)
    axs[0].set_ylabel("Y", fontsize=15)
    axs[0].tick_params(axis='both', labelsize=15)
    # Draw 100x100 grid lines for “signature”
    for i in range(1, grid_size):
        axs[0].axhline(i * cell_size, color='gray', linestyle='-', linewidth=0.5)
        axs[0].axvline(i * cell_size, color='gray', linestyle='-', linewidth=0.5)
    axs[0].grid(False)

    # RPS-I-HHO
    axs[1].scatter(population_snapshots_rpsihho[generation][:, 0],
                   population_snapshots_rpsihho[generation][:, 1],
                   c="black", s=10, alpha=1.0)
    axs[1].set_title("RPS-I-HHO - Generation: {}".format(generation), fontsize=20)
    axs[1].set_xlim(0, 1)
    axs[1].set_ylim(0, 1)
    axs[1].set_xlabel("X", fontsize=15)
    axs[1].set_ylabel("Y", fontsize=15)
    axs[1].tick_params(axis='both', labelsize=15)
    for i in range(1, grid_size):
        axs[1].axhline(i * cell_size, color='gray', linestyle='-', linewidth=0.5)
        axs[1].axvline(i * cell_size, color='gray', linestyle='-', linewidth=0.5)
    axs[1].grid(False)

    plt.tight_layout()
    plt.show()
