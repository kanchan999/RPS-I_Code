# Code for Structural Bias Determination in WOA and RPS-I-WOA Using the Generalized Signature Test
# Paper title: Regenerative Population Strategy-I: A Dynamic Methodology to Mitigate
#              Structural Bias in Metaheuristic Algorithms)
# Author: Kanchan Rajwar
# For assistance, contact: kanchanrajwar1519@gmail.com
# ======================================================================================================================
# ======================================================================================================================

import numpy as np
import random
import matplotlib.pyplot as plt
import matplotlib.patches as patches

# ======================================================================================================================
# WOA Parameters
#  a decreases linearly from 2 to 0
#  b = 2 (exponent for the spiral mechanism)
# ======================================================================================================================

def objective_function(solution):
    """
    Uniformly random objective function as per the study.
    The returned value is in [0,1], and we want to MINIMIZE it.
    """
    return np.random.uniform(0, 1)

# ======================================================================================================================
def initialize_population(pop_size, dimensions, bounds=(0,1)):
    """
    Initialize the population in [0,1]^dimensions.
    """
    return np.random.uniform(bounds[0], bounds[1], (pop_size, dimensions))

# ======================================================================================================================
def calculate_population_diversity(population):
    """
    Calculate diversity (alpha) as the sum of Euclidean distances from the mean position.
    A higher value indicates a more spread-out (diverse) population.
    """
    mean_position = np.mean(population, axis=0)
    diversity = np.sum([np.linalg.norm(ind - mean_position) for ind in population])
    return diversity

# ======================================================================================================================
def calculate_improvement_rate(fitness_best_prev, fitness_best_current):
    """
    Calculate improvement rate (beta) as the relative change in the best (lowest) fitness.
    A higher value indicates faster convergence.
    """
    return (fitness_best_prev - fitness_best_current) / (fitness_best_current + 1e-9)  # Avoid division by zero

# ======================================================================================================================
def calculate_gamma(alpha, alpha_max, beta, beta_max, w_alpha=0.5, w_beta=0.5):
    """
    Calculate the combined score gamma as a weighted sum of the normalized diversity (alpha/alpha_max)
    and improvement rate (beta/beta_max). gamma is clipped to [0,1].
    """
    alpha_max = max(alpha_max, alpha)
    beta_max = max(beta_max, beta)
    gamma = w_alpha * (alpha / alpha_max) + w_beta * (beta / beta_max)
    gamma = np.clip(gamma, 0, 1)
    return gamma, alpha_max, beta_max

# ======================================================================================================================
def calculate_ssf(population, dimensions, grid_cells=8):
    """
    Calculate the Signature Factor (SSF) based on the population's density in a grid.
    This metric is the ratio of empty hypercubes to the total number of hypercubes.
    """
    grid_size = grid_cells
    grid = np.zeros((grid_size,) * dimensions)
    for individual in population:
        # Convert each coordinate to an integer index in the grid
        indices = tuple((individual * grid_size).astype(int) % grid_size)
        grid[indices] += 1
    empty_hypercubes = np.sum(grid == 0)
    return float(empty_hypercubes / (grid_size ** dimensions))  # normalized by total cell count

# ======================================================================================================================
def apply_rps_i(population, gamma, best_index=None, bounds=(0,1), print_info=False):
    """
    Apply RPS-I by regenerating a subset of the population based on gamma.
    The number of individuals to regenerate is:
       N_regen = floor((1 - gamma) * (P - 1))
    The best solution (best_index) is preserved.
    """
    N = len(population)
    num_to_regenerate = int(np.floor((1 - gamma) * (N - 1)))

    # Exclude the best solution
    indices = np.arange(N)
    if best_index is not None:
        indices = np.delete(indices, best_index)

    if num_to_regenerate > 0 and len(indices) > 0:
        regen_indices = np.random.choice(indices, min(num_to_regenerate, len(indices)), replace=False)
        if print_info:
            print(f"    Regenerating individuals at indices: {regen_indices}")
        for i in regen_indices:
            population[i] = np.random.uniform(bounds[0], bounds[1], population.shape[1])

    return population

# ======================================================================================================================
# Standard Whale Optimization Algorithm (WOA)
# ======================================================================================================================
def standard_woa(pop_size, dimensions, max_generations=100, bounds=(0,1)):
    """
    Standard WOA:
      - Initialize population
      - For each iteration:
        - Find best solution (prey)
        - For each whale, update position (encircling, bubble-net, or search)
        - 'a' decreases from 2 to 0
        - Compute SSF each iteration
    """

    # 1) Initialize
    population = initialize_population(pop_size, dimensions, bounds)
    scores = np.array([objective_function(ind) for ind in population])

    # Identify the best solution
    best_index = np.argmin(scores)
    best_score = scores[best_index]
    best_pos = population[best_index].copy()

    # 2) Main loop
    ssf_values = []

    for gen in range(max_generations):
        # measure SSF
        ssf_values.append(calculate_ssf(population, dimensions))

        # linearly decrease a from 2 -> 0
        a = 2.0 - (2.0 * gen / (max_generations - 1))
        b = 2.0  # As given in the question

        for i in range(pop_size):
            r1 = np.random.rand()   # used to compute A, C
            r2 = np.random.rand()   # used to compute A, C

            A = 2.0 * a * r1 - a    # A in [-a, a]
            C = 2.0 * r2            # C in [0, 2]

            p = np.random.rand()    # used to switch between encircling/bubble-net vs search

            dist_to_best = np.linalg.norm(population[i] - best_pos)
            if p < 0.5:
                # Encircling or Spiral
                if abs(A) < 1:
                    # Encircling
                    D = abs(C * best_pos - population[i])
                    new_pos = best_pos - A * D
                else:
                    # Search
                    # Pick random whale j
                    rand_index = np.random.randint(pop_size)
                    X_rand = population[rand_index]
                    D = abs(C * X_rand - population[i])
                    new_pos = X_rand - A * D
            else:
                # Bubble-net (spiral)
                D_prime = dist_to_best
                l = (np.random.rand() * 2) - 1  # l in [-1,1]
                # b is the spiral constant, here b=2
                new_pos = (best_pos - population[i])
                # update with spiral:
                new_pos = new_pos * np.exp(b * l) * np.cos(2.0 * np.pi * l) + population[i]

            # clip to bounds
            new_pos = np.clip(new_pos, bounds[0], bounds[1])
            population[i] = new_pos

        # evaluate new population
        scores = np.array([objective_function(ind) for ind in population])
        # update best
        curr_best_index = np.argmin(scores)
        curr_best_score = scores[curr_best_index]
        if curr_best_score < best_score:
            best_score = curr_best_score
            best_pos = population[curr_best_index].copy()

    return ssf_values

# ======================================================================================================================
# RPS-I-WOA
# ======================================================================================================================
def rps_i_woa(pop_size, dimensions, max_generations=100, bounds=(0,1)):
    """
    Whale Optimization Algorithm with RPS-I:
      - Compute alpha (population diversity), beta (improvement rate), gamma
      - Reinitialize part of the population based on gamma
      - Then do standard WOA update
    """

    # 1) Initialize
    population = initialize_population(pop_size, dimensions, bounds)
    scores = np.array([objective_function(ind) for ind in population])

    best_index = np.argmin(scores)
    best_score = scores[best_index]
    best_pos = population[best_index].copy()

    # for RPS-I metrics
    alpha_max, beta_max = 1e-6, 1e-6
    fitness_best_prev = best_score

    ssf_values = []

    for gen in range(max_generations):
        # 1) Identify best solution (prey)
        best_index = np.argmin(scores)
        best_score = scores[best_index]
        best_pos = population[best_index].copy()

        # 2) RPS-I metrics
        diversity = calculate_population_diversity(population)
        improvement = calculate_improvement_rate(fitness_best_prev, best_score)
        gamma, alpha_max, beta_max = calculate_gamma(diversity, alpha_max, improvement, beta_max)

        # 3) RPS-I reinitialization
        num_to_regen = int(np.floor((1 - gamma) * (len(population) - 1)))
        print("------------------------------------------------------------------------------------------------------------------")
        print(f"Generation {gen}: gamma = {gamma:.4f}, reinitialize count = {num_to_regen}")
        population = apply_rps_i(population, gamma, best_index=best_index, bounds=bounds, print_info=True)

        # 4) measure SSF after reinit
        ssf_after_reinit = calculate_ssf(population, dimensions)
        print(f"    SSF : {ssf_after_reinit:.4f}")
        ssf_values.append(ssf_after_reinit)

        # 5) Standard WOA update
        # re-evaluate if population changed
        scores = np.array([objective_function(ind) for ind in population])
        best_index = np.argmin(scores)
        best_score = scores[best_index]
        best_pos = population[best_index].copy()

        a = 2.0 - (2.0 * gen / (max_generations - 1))  # linear decrease
        b = 2.0                                       # spiral constant

        for i in range(pop_size):
            r1 = np.random.rand()
            r2 = np.random.rand()

            A = 2.0 * a * r1 - a
            C = 2.0 * r2

            p = np.random.rand()

            dist_to_best = np.linalg.norm(population[i] - best_pos)

            if p < 0.5:
                # Encircling or Search
                if abs(A) < 1:
                    # Encircling
                    D = abs(C * best_pos - population[i])
                    new_pos = best_pos - A * D
                else:
                    # Search
                    rand_index = np.random.randint(pop_size)
                    X_rand = population[rand_index]
                    D = abs(C * X_rand - population[i])
                    new_pos = X_rand - A * D
            else:
                # Bubble-net (spiral)
                D_prime = dist_to_best
                l = (np.random.rand() * 2) - 1  # l in [-1,1]
                new_pos = (best_pos - population[i])
                new_pos = new_pos * np.exp(b * l) * np.cos(2.0 * np.pi * l) + population[i]

            # Clip to bounds
            new_pos = np.clip(new_pos, bounds[0], bounds[1])
            population[i] = new_pos

        # Evaluate new population
        scores = np.array([objective_function(ind) for ind in population])

        # Update fitness_best_prev for next generation
        curr_best_index = np.argmin(scores)
        fitness_best_prev = scores[curr_best_index]

    return ssf_values

# ======================================================================================================================
# Main Execution
# ======================================================================================================================
if __name__ == "__main__":
    # Parameters
    dimensions = 3         # Dimensionality of the problem ([0,1]^3)
    pop_size = 512         # Population size
    max_generations = 100  # Number of generations
    bounds = (0,1)

    # Run standard WOA
    ssf_values_woa = standard_woa(pop_size, dimensions, max_generations, bounds)

    # Run RPS-I-WOA
    ssf_values_rps_woa = rps_i_woa(pop_size, dimensions, max_generations, bounds)

    print("------------------------------------------------------------------------------------------------------------------")

    # Print SSF comparison for selected iterations
    print("SSF values for particular iterations of Standard WOA:")
    print(f"Iteration 0:  {ssf_values_woa[0]:.4f}")
    print(f"Iteration 24: {ssf_values_woa[24]:.4f}")
    print(f"Iteration 49: {ssf_values_woa[49]:.4f}")
    print(f"Iteration 74: {ssf_values_woa[74]:.4f}")
    print(f"Iteration 99: {ssf_values_woa[99]:.4f}")

    print("------------------------------------------------------------------------------------------------------------------")

    print("\nSSF values for particular iterations of RPS-I WOA:")
    print(f"Iteration 0:  {ssf_values_rps_woa[0]:.4f}")
    print(f"Iteration 24: {ssf_values_rps_woa[24]:.4f}")
    print(f"Iteration 49: {ssf_values_rps_woa[49]:.4f}")
    print(f"Iteration 74: {ssf_values_rps_woa[74]:.4f}")
    print(f"Iteration 99: {ssf_values_rps_woa[99]:.4f}")

    # Plot the results
    plt.figure(figsize=(10, 6))
    plt.plot(ssf_values_woa, label="WOA", marker='o', markersize=4, linewidth=2)
    plt.plot(ssf_values_rps_woa, label="RPS-I-WOA", marker='s', markersize=4, linewidth=2)
    plt.legend(fontsize=16)
    plt.xlim(0, max_generations)
    plt.ylim(0.3, 1)
    plt.xlabel("Iteration", fontsize=16)
    plt.ylabel("Signature Factor (η)", fontsize=16)
    plt.grid(True)

    # Add a thick border around the plot area
    border_thickness = 5
    plt.gca().add_patch(
        patches.Rectangle(
            (0, 0), 1, 1, transform=plt.gca().transAxes,
            linewidth=border_thickness, edgecolor='black', facecolor='none'
        )
    )

    plt.show()
    print("------------------------------------------------------------------------------------------------------------------")
# ======================================================================================================================
# ======================================================================================================================
