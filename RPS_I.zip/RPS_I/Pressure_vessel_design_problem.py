# Code for PRESSURE VESSEL DESIGN PROBLEM (Table 13)
# Paper title: Regenerative Population Strategy-I: A Dynamic Methodology to Mitigate
#              Structural Bias in Metaheuristic Algorithms)
# Author: Kanchan Rajwar
# For assistance, contact: kanchanrajwar1519@gmail.com
#=======================================================================================================================
#=======================================================================================================================
import numpy as np

# ===================================================================================
#  PRESSURE VESSEL DESIGN PROBLEM (Objective + Constraints + Penalized Fitness)
# ===================================================================================
P = 100  #pop_size      #Set accoridng to your choice
I = 5000 #max_gens      #Set accoridng to your choice

def vessel_objective(x):
    """
    Objective:
      f(x) = 0.6224*x1*x3*x4 + 1.7781*x2*x3^2 + 3.166*x1^2*x4 + 19.84*x1^2*x3
    x = [x1, x2, x3, x4].
    """
    x1, x2, x3, x4 = x
    return 0.6224*x1*x3*x4 + 1.7781*x2*x3**2 + 3.166*x1**2*x4 + 19.84*x1**2*x3

# def vessel_constraints(x):
#     """
#     Constraints:
#       g1(x) = x1 + 0.0193*x3 <= 0
#       g2(x) = -x2 + 0.00954*x3 <= 0
#       g3(x) = -pi*x3^2*x4 - (4/3)*pi*x3^3 + 1296000 <= 0
#       g4(x) = x4 - 240 <= 0
#     Returns list [g1, g2, g3, g4].
#     """
#     x1, x2, x3, x4 = x
#     g1 = x1 - 0.0193 * x3  # <= 0
#     g2 = x2 - 0.00954 * x3  # <= 0
#     g3 = -np.pi*x3**2*x4 - (4.0/3.0)*np.pi*x3**3 + 1296000.0
#     g4 = x4 - 240.0
#     return [g1, g2, g3, g4]
def vessel_constraints(x):
    """
    g1(x) = x1 - 0.0193*x3 <= 0
    g2(x) = x2 - 0.00954*x3 <= 0
    g3(x) = -pi*x3^2*x4 - (4/3)*pi*x3^3 + 1296000 <= 0
    g4(x) = x4 - 240 <= 0

    + ADD these so x1,x2 >=0.0625:
      g5(x) = 0.0625 - x1 <= 0
      g6(x) = 0.0625 - x2 <= 0
    """
    x1, x2, x3, x4 = x

    g1 = x1 - 0.0193*x3
    g2 = x2 - 0.00954*x3
    g3 = -np.pi*(x3**2)*x4 - (4.0/3.0)*np.pi*(x3**3) + 1296000.0
    g4 = x4 - 240.0

    # New constraints: enforce minimal thickness 0.0625
    g5 = 0.0625 - x1
    g6 = 0.0625 - x2

    return [g1, g2, g3, g4, g5, g6]

def vessel_penalized_fitness(x, penalty_factor=1e6):
    """
    Penalized fitness = objective + penalty_factor * sum_of_positive_constraint_violations.
    """
    f = vessel_objective(x)
    c = vessel_constraints(x)
    violation_sum = sum(max(0.0, g) for g in c)
    return f + penalty_factor*violation_sum

# Bounds for [x1, x2, x3, x4]
lower_bounds = np.array([0.0, 0.0, 10.0, 10.0])
upper_bounds = np.array([99.0, 99.0, 200.0, 200.0])

def clip_to_bounds(x):
    """Ensure x is within [lb, ub] for each dimension."""
    return np.clip(x, lower_bounds, upper_bounds)

# ===================================================================================
# 2) RPS-I HELPER FUNCTIONS (Diversity, Improvement, RPS-I Update)
# ===================================================================================
def calculate_diversity(population):
    """
    alpha = sum of Euclidean distances from mean.
    population shape: (pop_size, 4).
    """
    mean_pos = np.mean(population, axis=0)
    return np.sum(np.linalg.norm(population - mean_pos, axis=1))

def calculate_improvement_rate(prev_best, curr_best):
    """
    beta = (prev_best - curr_best)/(curr_best + 1e-9)
    """
    return (prev_best - curr_best)/(curr_best + 1e-9)

def update_rps_i(population, fitnesses, alpha_max, beta_max, prev_best_f, w_alpha=0.5, w_beta=0.5):
    """
    1) alpha = population diversity
    2) beta = improvement rate vs prev_best_f
    3) gamma = w_alpha*(alpha/alpha_max) + w_beta*(beta/beta_max), clipped [0,1]
    4) Reinit (1-gamma)*(N-1) solutions, preserving best.

    Returns updated (population, fitnesses, alpha_max, beta_max, new_prev_best).
    """
    pop_size = len(population)
    best_idx = np.argmin(fitnesses)
    best_val = fitnesses[best_idx]

    alpha = calculate_diversity(population)
    alpha_max = max(alpha_max, alpha)

    beta = calculate_improvement_rate(prev_best_f, best_val)
    beta_max = max(beta_max, beta)

    gamma = w_alpha*(alpha/alpha_max) + w_beta*(beta/beta_max)
    gamma = np.clip(gamma, 0.0, 1.0)

    num_to_regen = int(np.floor((1.0 - gamma)*(pop_size - 1)))
    if num_to_regen > 0:
        indices = np.arange(pop_size)
        # Exclude the current best from regeneration
        indices = np.delete(indices, best_idx)
        if len(indices) > 0:
            regen_idxs = np.random.choice(indices, min(num_to_regen,len(indices)), replace=False)
            for idx in regen_idxs:
                rnd = np.random.rand(4)
                new_sol = lower_bounds + rnd*(upper_bounds - lower_bounds)
                population[idx] = new_sol
                fitnesses[idx]  = vessel_penalized_fitness(new_sol)

    new_prev_best = min(best_val, prev_best_f)
    return population, fitnesses, alpha_max, beta_max, new_prev_best

# ===================================================================================
# 3) ALGORITHMS: GA, RPS-I-GA
# ===================================================================================
def ga_vessel(pop_size=P, max_gens=I):
    crossover_rate = 1.0
    mutation_rate  = 0.01

    # initialize
    population = []
    for _ in range(pop_size):
        rnd = np.random.rand(4)
        x   = lower_bounds + rnd*(upper_bounds - lower_bounds)
        population.append(x)
    population = np.array(population)
    fitnesses  = np.array([vessel_penalized_fitness(ind) for ind in population])

    def roulette_selection(pop, fits):
        # Minimizing => define raw_fit ~ 1/(1+cost)
        raw_fit = 1.0/(1.0 + fits)
        total   = np.sum(raw_fit)
        if total<1e-12:
            indices = np.random.randint(0, len(pop), size=len(pop))
            return pop[indices]
        cdf = np.cumsum(raw_fit/total)
        new_pop = []
        for _ in range(len(pop)):
            r = np.random.rand()
            idx = np.searchsorted(cdf, r)
            new_pop.append(pop[idx])
        return np.array(new_pop)

    def single_point_crossover(p1, p2):
        cp = np.random.randint(1,4)
        c1 = np.concatenate([p1[:cp], p2[cp:]])
        c2 = np.concatenate([p2[:cp], p1[cp:]])
        return c1, c2

    def mutate(child):
        for d in range(4):
            if np.random.rand()<mutation_rate:
                child[d] = lower_bounds[d] + (upper_bounds[d]-lower_bounds[d])*np.random.rand()
        return child

    for gen in range(max_gens):
        # selection
        mating_pool = roulette_selection(population, fitnesses)
        # crossover + mutation
        new_pop = []
        for i in range(0, pop_size, 2):
            p1 = mating_pool[i]
            if i+1<pop_size:
                p2 = mating_pool[i+1]
            else:
                p2 = p1
            if np.random.rand()<crossover_rate:
                c1, c2 = single_point_crossover(p1,p2)
            else:
                c1, c2 = np.copy(p1), np.copy(p2)
            c1 = mutate(c1)
            c2 = mutate(c2)
            c1 = clip_to_bounds(c1)
            c2 = clip_to_bounds(c2)
            new_pop.append(c1)
            new_pop.append(c2)
        population = np.array(new_pop)[:pop_size]
        fitnesses  = np.array([vessel_penalized_fitness(ind) for ind in population])

    b_idx = np.argmin(fitnesses)
    return population[b_idx], fitnesses[b_idx]

def rps_i_ga_vessel(pop_size=P, max_gens=I):
    crossover_rate = 1.0
    mutation_rate  = 0.01

    population = []
    for _ in range(pop_size):
        rnd = np.random.rand(4)
        x   = lower_bounds + rnd*(upper_bounds - lower_bounds)
        population.append(x)
    population = np.array(population)
    fitnesses  = np.array([vessel_penalized_fitness(ind) for ind in population])

    alpha_max, beta_max = 1e-6, 1e-6
    best_idx = np.argmin(fitnesses)
    prev_best= fitnesses[best_idx]

    def roulette_selection(pop, fits):
        raw_fit = 1.0/(1.0 + fits)
        total   = np.sum(raw_fit)
        if total<1e-12:
            indices = np.random.randint(0, len(pop), size=len(pop))
            return pop[indices]
        cdf = np.cumsum(raw_fit/total)
        new_pop = []
        for _ in range(len(pop)):
            r = np.random.rand()
            idx= np.searchsorted(cdf, r)
            new_pop.append(pop[idx])
        return np.array(new_pop)

    def single_point_crossover(p1, p2):
        cp = np.random.randint(1,4)
        c1 = np.concatenate([p1[:cp], p2[cp:]])
        c2 = np.concatenate([p2[:cp], p1[cp:]])
        return c1, c2

    def mutate(child):
        for d in range(4):
            if np.random.rand()<mutation_rate:
                child[d] = lower_bounds[d] + (upper_bounds[d]-lower_bounds[d])*np.random.rand()
        return child

    for gen in range(max_gens):
        # RPS-I
        population, fitnesses, alpha_max, beta_max, prev_best = update_rps_i(
            population, fitnesses, alpha_max, beta_max, prev_best
        )
        # GA step
        mating_pool = roulette_selection(population, fitnesses)
        new_pop = []
        for i in range(0, pop_size, 2):
            p1 = mating_pool[i]
            if i+1<pop_size:
                p2 = mating_pool[i+1]
            else:
                p2 = p1
            if np.random.rand()<crossover_rate:
                c1,c2 = single_point_crossover(p1,p2)
            else:
                c1,c2 = np.copy(p1), np.copy(p2)
            c1 = mutate(c1)
            c2 = mutate(c2)
            c1 = clip_to_bounds(c1)
            c2 = clip_to_bounds(c2)
            new_pop.append(c1)
            new_pop.append(c2)
        population = np.array(new_pop)[:pop_size]
        fitnesses  = np.array([vessel_penalized_fitness(ind) for ind in population])

    b_idx = np.argmin(fitnesses)
    return population[b_idx], fitnesses[b_idx]

# ===================================================================================
# 4) PSO, RPS-I-PSO
# ===================================================================================
def pso_vessel(pop_size=P, max_gens=I):
    w_max, w_min = 0.9, 0.1
    c1, c2 = 2.0, 2.0

    positions = lower_bounds + np.random.rand(pop_size,4)*(upper_bounds - lower_bounds)
    velocities= 0.1*(np.random.rand(pop_size,4)*2.0 - 1.0)

    p_best_pos = np.copy(positions)
    p_best_fit = np.array([vessel_penalized_fitness(x) for x in positions])
    g_idx  = np.argmin(p_best_fit)
    g_best = p_best_pos[g_idx].copy()
    g_fit  = p_best_fit[g_idx]

    for gen in range(max_gens):
        w_t = w_max - (w_max - w_min)*gen/(max_gens-1)
        for i in range(pop_size):
            fit_i = vessel_penalized_fitness(positions[i])
            if fit_i < p_best_fit[i]:
                p_best_fit[i] = fit_i
                p_best_pos[i] = positions[i].copy()
            if fit_i < g_fit:
                g_fit = fit_i
                g_best= positions[i].copy()

        # Update
        for i in range(pop_size):
            r1,r2 = np.random.rand(4), np.random.rand(4)
            cognitive = c1*r1*(p_best_pos[i] - positions[i])
            social    = c2*r2*(g_best - positions[i])
            velocities[i] = w_t*velocities[i] + cognitive + social
            positions[i] += velocities[i]
            positions[i] = clip_to_bounds(positions[i])

    return g_best, g_fit

def rps_i_pso_vessel(pop_size=P, max_gens=I):
    w_max, w_min = 0.9, 0.1
    c1, c2 = 2.0, 2.0

    positions = lower_bounds + np.random.rand(pop_size,4)*(upper_bounds - lower_bounds)
    velocities= 0.1*(np.random.rand(pop_size,4)*2.0 -1.0)

    p_best_pos = np.copy(positions)
    p_best_fit = np.array([vessel_penalized_fitness(x) for x in positions])
    g_idx  = np.argmin(p_best_fit)
    g_best= p_best_pos[g_idx].copy()
    g_fit = p_best_fit[g_idx]

    alpha_max, beta_max = 1e-6, 1e-6
    prev_best = g_fit

    for gen in range(max_gens):
        # RPS-I
        positions, p_best_fit, alpha_max, beta_max, prev_best = update_rps_i(
            positions, p_best_fit, alpha_max, beta_max, prev_best
        )
        # Possibly reset velocities of reinit individuals:
        velocities= 0.1*(np.random.rand(pop_size,4)*2.0 -1.0)

        # Update personal & global best after reinit
        for i in range(pop_size):
            fit_i = vessel_penalized_fitness(positions[i])
            if fit_i < p_best_fit[i]:
                p_best_fit[i] = fit_i
                p_best_pos[i] = positions[i].copy()
        g_idx = np.argmin(p_best_fit)
        g_fit = p_best_fit[g_idx]
        g_best= p_best_pos[g_idx].copy()

        # Standard PSO
        w_t = w_max - (w_max - w_min)*gen/(max_gens-1)
        for i in range(pop_size):
            r1,r2 = np.random.rand(4), np.random.rand(4)
            cognitive = c1*r1*(p_best_pos[i] - positions[i])
            social    = c2*r2*(g_best - positions[i])
            velocities[i] = w_t*velocities[i] + cognitive + social
            positions[i] += velocities[i]
            positions[i] = clip_to_bounds(positions[i])
            # update personal/global best
            fit_i = vessel_penalized_fitness(positions[i])
            if fit_i < p_best_fit[i]:
                p_best_fit[i] = fit_i
                p_best_pos[i] = positions[i].copy()
            if fit_i < g_fit:
                g_fit = fit_i
                g_best= positions[i].copy()

    return g_best, g_fit

# ===================================================================================
# 5) DE, RPS-I-DE
# ===================================================================================
def de_vessel(pop_size=P, max_gens=I, F=0.5, CR=0.5):
    population = lower_bounds + np.random.rand(pop_size,4)*(upper_bounds - lower_bounds)
    fitnesses  = np.array([vessel_penalized_fitness(x) for x in population])

    for gen in range(max_gens):
        for i in range(pop_size):
            idxs = [idx for idx in range(pop_size) if idx!=i]
            r1, r2, r3 = np.random.choice(idxs, 3, replace=False)
            donor = population[r1] + F*(population[r2] - population[r3])
            donor = clip_to_bounds(donor)
            trial = np.copy(population[i])
            rand_dim = np.random.randint(4)
            for d in range(4):
                if np.random.rand()<CR or d==rand_dim:
                    trial[d] = donor[d]
            trial = clip_to_bounds(trial)
            t_fit = vessel_penalized_fitness(trial)
            if t_fit < fitnesses[i]:
                population[i] = trial
                fitnesses[i]  = t_fit

    best_idx = np.argmin(fitnesses)
    return population[best_idx], fitnesses[best_idx]

def rps_i_de_vessel(pop_size=P, max_gens=I, F=0.5, CR=0.5):
    population = lower_bounds + np.random.rand(pop_size,4)*(upper_bounds - lower_bounds)
    fitnesses  = np.array([vessel_penalized_fitness(x) for x in population])

    alpha_max, beta_max = 1e-6, 1e-6
    best_idx = np.argmin(fitnesses)
    prev_best= fitnesses[best_idx]

    for gen in range(max_gens):
        # RPS-I
        population, fitnesses, alpha_max, beta_max, prev_best = update_rps_i(
            population, fitnesses, alpha_max, beta_max, prev_best
        )
        # DE iteration
        for i in range(len(population)):
            idxs = [idx for idx in range(len(population)) if idx!=i]
            r1,r2,r3 = np.random.choice(idxs, 3, replace=False)
            donor = population[r1] + F*(population[r2] - population[r3])
            donor = clip_to_bounds(donor)
            trial = np.copy(population[i])
            rand_dim = np.random.randint(4)
            for d in range(4):
                if np.random.rand()<CR or d==rand_dim:
                    trial[d] = donor[d]
            trial = clip_to_bounds(trial)
            t_fit = vessel_penalized_fitness(trial)
            if t_fit < fitnesses[i]:
                population[i] = trial
                fitnesses[i]  = t_fit

    b_idx = np.argmin(fitnesses)
    return population[b_idx], fitnesses[b_idx]

# ===================================================================================
# 6) GWO, RPS-I-GWO
# ===================================================================================
def gwo_vessel(pop_size=P, max_gens=I):
    population = lower_bounds + np.random.rand(pop_size,4)*(upper_bounds - lower_bounds)
    fitnesses  = np.array([vessel_penalized_fitness(x) for x in population])

    for gen in range(max_gens):
        sort_idx = np.argsort(fitnesses)
        alpha, beta, delta = sort_idx[0], sort_idx[1], sort_idx[2]
        alpha_pos = population[alpha].copy()
        beta_pos  = population[beta].copy()
        delta_pos = population[delta].copy()

        a = 2.0 - 2.0*(gen/(max_gens-1))
        for i in range(pop_size):
            X = population[i]
            r1,r2 = np.random.rand(), np.random.rand()
            A1 = 2*a*r1 - a
            C1 = 2*r2
            Dalpha = abs(C1*alpha_pos - X)
            X1 = alpha_pos - A1*Dalpha

            r1,r2 = np.random.rand(), np.random.rand()
            A2 = 2*a*r1 - a
            C2 = 2*r2
            Dbeta = abs(C2*beta_pos - X)
            X2 = beta_pos - A2*Dbeta

            r1,r2 = np.random.rand(), np.random.rand()
            A3 = 2*a*r1 - a
            C3 = 2*r2
            Ddelta = abs(C3*delta_pos - X)
            X3 = delta_pos - A3*Ddelta

            newX = (X1 + X2 + X3)/3.0
            newX = clip_to_bounds(newX)
            newFit= vessel_penalized_fitness(newX)
            if newFit < fitnesses[i]:
                population[i] = newX
                fitnesses[i]  = newFit

    b_idx = np.argmin(fitnesses)
    return population[b_idx], fitnesses[b_idx]

def rps_i_gwo_vessel(pop_size=P, max_gens=I):
    population = lower_bounds + np.random.rand(pop_size,4)*(upper_bounds - lower_bounds)
    fitnesses  = np.array([vessel_penalized_fitness(x) for x in population])

    alpha_max, beta_max = 1e-6, 1e-6
    best_idx = np.argmin(fitnesses)
    prev_best= fitnesses[best_idx]

    for gen in range(max_gens):
        population, fitnesses, alpha_max, beta_max, prev_best = update_rps_i(
            population, fitnesses, alpha_max, beta_max, prev_best
        )
        # GWO iteration
        sort_idx = np.argsort(fitnesses)
        alpha, beta, delta = sort_idx[0], sort_idx[1], sort_idx[2]
        alpha_pos = population[alpha].copy()
        beta_pos  = population[beta].copy()
        delta_pos = population[delta].copy()

        a = 2.0 - 2.0*(gen/(max_gens-1))
        for i in range(pop_size):
            X = population[i]
            r1,r2 = np.random.rand(), np.random.rand()
            A1 = 2*a*r1 - a
            C1 = 2*r2
            Dalpha = abs(C1*alpha_pos - X)
            X1 = alpha_pos - A1*Dalpha

            r1,r2 = np.random.rand(), np.random.rand()
            A2 = 2*a*r1 - a
            C2 = 2*r2
            Dbeta = abs(C2*beta_pos - X)
            X2 = beta_pos - A2*Dbeta

            r1,r2 = np.random.rand(), np.random.rand()
            A3 = 2*a*r1 - a
            C3 = 2*r2
            Ddelta = abs(C3*delta_pos - X)
            X3 = delta_pos - A3*Ddelta

            newX = (X1 + X2 + X3)/3.0
            newX = clip_to_bounds(newX)
            newFit= vessel_penalized_fitness(newX)
            if newFit< fitnesses[i]:
                population[i] = newX
                fitnesses[i]  = newFit

    b_idx = np.argmin(fitnesses)
    return population[b_idx], fitnesses[b_idx]

# ===================================================================================
# 7) WOA, RPS-I-WOA
# ===================================================================================
def woa_vessel(pop_size=P, max_gens=I):
    population = lower_bounds + np.random.rand(pop_size,4)*(upper_bounds - lower_bounds)
    fitnesses  = np.array([vessel_penalized_fitness(x) for x in population])

    for gen in range(max_gens):
        best_idx = np.argmin(fitnesses)
        best_sol = population[best_idx].copy()

        a = 2.0 - 2.0*(gen/(max_gens-1))
        b = 1.0

        for i in range(pop_size):
            A = 2.0*a*np.random.rand() - a
            C = 2.0*np.random.rand()
            p = np.random.rand()
            if p<0.5:
                # encircling/search
                if abs(A)<1:
                    D = abs(C*best_sol - population[i])
                    newX = best_sol - A*D
                else:
                    rand_idx = np.random.randint(pop_size)
                    X_rand   = population[rand_idx]
                    D = abs(C*X_rand - population[i])
                    newX = X_rand - A*D
            else:
                # bubble-net
                dist = np.linalg.norm(best_sol - population[i])
                l = (np.random.rand()*2)-1
                newX = (best_sol - population[i]) * np.exp(b*l)*np.cos(2*np.pi*l) + population[i]

            newX = clip_to_bounds(newX)
            newFit= vessel_penalized_fitness(newX)
            if newFit<fitnesses[i]:
                population[i] = newX
                fitnesses[i]  = newFit

    b_idx = np.argmin(fitnesses)
    return population[b_idx], fitnesses[b_idx]

def rps_i_woa_vessel(pop_size=P, max_gens=I):
    population = lower_bounds + np.random.rand(pop_size,4)*(upper_bounds - lower_bounds)
    fitnesses  = np.array([vessel_penalized_fitness(x) for x in population])

    alpha_max, beta_max = 1e-6, 1e-6
    best_idx = np.argmin(fitnesses)
    prev_best= fitnesses[best_idx]

    for gen in range(max_gens):
        population, fitnesses, alpha_max, beta_max, prev_best = update_rps_i(
            population, fitnesses, alpha_max, beta_max, prev_best
        )
        best_idx = np.argmin(fitnesses)
        best_sol = population[best_idx].copy()

        a = 2.0 - 2.0*(gen/(max_gens-1))
        b = 1.0
        for i in range(pop_size):
            A = 2.0*a*np.random.rand() - a
            C = 2.0*np.random.rand()
            p = np.random.rand()
            if p<0.5:
                if abs(A)<1:
                    D = abs(C*best_sol - population[i])
                    newX = best_sol - A*D
                else:
                    rand_idx = np.random.randint(pop_size)
                    X_rand   = population[rand_idx]
                    D = abs(C*X_rand - population[i])
                    newX = X_rand - A*D
            else:
                dist = np.linalg.norm(best_sol - population[i])
                l = (np.random.rand()*2)-1
                newX = (best_sol - population[i])*np.exp(b*l)*np.cos(2.0*np.pi*l) + population[i]

            newX = clip_to_bounds(newX)
            newFit= vessel_penalized_fitness(newX)
            if newFit<fitnesses[i]:
                population[i] = newX
                fitnesses[i]  = newFit

    b_idx = np.argmin(fitnesses)
    return population[b_idx], fitnesses[b_idx]

# ===================================================================================
# 8) HHO, RPS-I-HHO
# ===================================================================================
def hho_vessel(pop_size=P, max_gens=I):
    population = lower_bounds + np.random.rand(pop_size,4)*(upper_bounds - lower_bounds)
    fitnesses  = np.array([vessel_penalized_fitness(x) for x in population])

    for gen in range(max_gens):
        best_idx = np.argmin(fitnesses)
        best_fit = fitnesses[best_idx]
        best_sol = population[best_idx].copy()

        E_0 = -1.0 + 2.0*(gen/(max_gens-1))  # from -1->+1

        for i in range(pop_size):
            x_i  = population[i]
            fit_i= fitnesses[i]
            r1   = np.random.rand()
            r2   = np.random.rand()
            if abs(E_0)>=1:
                # exploration
                rand_idx = np.random.randint(pop_size)
                X_rand   = population[rand_idx]
                q = np.random.rand()
                D_rand= abs(q*X_rand - x_i)
                newX = X_rand - r1*D_rand
            else:
                # exploitation
                D_best= abs(r2*best_sol - x_i)
                L_J   = 2.0*(1-r2)
                if np.random.rand()<0.5:
                    # soft besiege
                    newX = best_sol - E_0*D_best
                else:
                    # hard besiege
                    newX = (best_sol - E_0*D_best) - r1*L_J*D_best
            newX = clip_to_bounds(newX)
            newFit= vessel_penalized_fitness(newX)
            if newFit<fitnesses[i]:
                population[i] = newX
                fitnesses[i]  = newFit

    b_idx= np.argmin(fitnesses)
    return population[b_idx], fitnesses[b_idx]

def rps_i_hho_vessel(pop_size=P, max_gens=I):
    population = lower_bounds + np.random.rand(pop_size,4)*(upper_bounds - lower_bounds)
    fitnesses  = np.array([vessel_penalized_fitness(x) for x in population])

    alpha_max, beta_max = 1e-6, 1e-6
    best_idx = np.argmin(fitnesses)
    prev_best= fitnesses[best_idx]

    for gen in range(max_gens):
        # RPS-I
        population, fitnesses, alpha_max, beta_max, prev_best = update_rps_i(
            population, fitnesses, alpha_max, beta_max, prev_best
        )
        # HHO iteration
        best_idx = np.argmin(fitnesses)
        best_sol = population[best_idx].copy()

        E_0 = -1.0 + 2.0*(gen/(max_gens-1))
        for i in range(pop_size):
            x_i  = population[i]
            fit_i= fitnesses[i]
            r1   = np.random.rand()
            r2   = np.random.rand()
            if abs(E_0)>=1:
                rand_idx = np.random.randint(pop_size)
                X_rand   = population[rand_idx]
                q = np.random.rand()
                D_rand= abs(q*X_rand - x_i)
                newX = X_rand - r1*D_rand
            else:
                D_best= abs(r2*best_sol - x_i)
                L_J   = 2.0*(1-r2)
                if np.random.rand()<0.5:
                    newX = best_sol - E_0*D_best
                else:
                    newX = (best_sol - E_0*D_best) - r1*L_J*D_best
            newX = clip_to_bounds(newX)
            newFit= vessel_penalized_fitness(newX)
            if newFit<fitnesses[i]:
                population[i] = newX
                fitnesses[i]  = newFit

    b_idx= np.argmin(fitnesses)
    return population[b_idx], fitnesses[b_idx]

# ===================================================================================
# 9) MAIN DEMO: RUN ALL 12 ALGORITHMS
# ===================================================================================
if __name__=="__main__":
    np.random.seed(0)

    algs = {
      "GA": ga_vessel,
      "RPS-I-GA": rps_i_ga_vessel,
      "PSO": pso_vessel,
      "RPS-I-PSO": rps_i_pso_vessel,
      "DE": de_vessel,
      "RPS-I-DE": rps_i_de_vessel,
      "GWO": gwo_vessel,
      "RPS-I-GWO": rps_i_gwo_vessel,
      "WOA": woa_vessel,
      "RPS-I-WOA": rps_i_woa_vessel,
      "HHO": hho_vessel,
      "RPS-I-HHO": rps_i_hho_vessel,
    }

    pop_size = P
    max_gens = I

    for name, func in algs.items():
        best_sol, best_fit = func(pop_size=pop_size, max_gens=max_gens)
        print(f"Algorithm: {name}")
        print(f"  Best solution: x = {best_sol}")
        print(f"  Best penalized fitness = {best_fit:.6f}")
        print(f"  Actual objective f(x) = {vessel_objective(best_sol):.6f}")
        # Check constraints
        c_vals = vessel_constraints(best_sol)
        feasible = all(g<=0 for g in c_vals)
        print(f"  Feasible? {feasible}, constraints= {c_vals}")
        print("------------------------------------------------------------")
