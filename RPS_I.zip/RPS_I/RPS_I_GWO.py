# Code for Structural Bias Determination in GWO and RPS-I-GWO Using the Generalized Signature Test
# Paper title: Regenerative Population Strategy-I: A Dynamic Methodology to Mitigate
#              Structural Bias in Metaheuristic Algorithms)
# Author: Kanchan Rajwar
# For assistance, contact: kanchanrajwar1519@gmail.com
# ======================================================================================================================
# ======================================================================================================================

import numpy as np
import random
import matplotlib.pyplot as plt
import matplotlib.patches as patches

# ======================================================================================================================
# GWO Parameter
# 'a' is linearly decreased from 2.0 to 0.0 over the course of iterations
# ======================================================================================================================

def objective_function(solution):
    """
    Uniformly random objective function as per the study.
    The returned value is in [0,1], and we want to MINIMIZE it.
    """
    return np.random.uniform(0, 1)

# ======================================================================================================================
def initialize_population(pop_size, dimensions, bounds=(0,1)):
    """
    Initialize the population in [0,1]^dimensions for each wolf.
    """
    return np.random.uniform(bounds[0], bounds[1], (pop_size, dimensions))

# ======================================================================================================================
def calculate_population_diversity(population):
    """
    Calculate diversity (alpha) as the sum of Euclidean distances from the mean position.
    A higher value indicates a more spread-out (diverse) population.
    """
    mean_position = np.mean(population, axis=0)
    diversity = np.sum([np.linalg.norm(ind - mean_position) for ind in population])
    return diversity

# ======================================================================================================================
def calculate_improvement_rate(fitness_best_prev, fitness_best_current):
    """
    Calculate improvement rate (beta) as the relative change in the best (lowest) fitness.
    A higher value indicates faster convergence.
    """
    return (fitness_best_prev - fitness_best_current) / (fitness_best_current + 1e-9)  # Avoid division by zero

# ======================================================================================================================
def calculate_gamma(alpha, alpha_max, beta, beta_max, w_alpha=0.5, w_beta=0.5):
    """
    Calculate the combined score gamma as a weighted sum of the normalized diversity (alpha/alpha_max)
    and improvement rate (beta/beta_max). gamma is clipped to [0,1].
    """
    alpha_max = max(alpha_max, alpha)
    beta_max = max(beta_max, beta)
    gamma = w_alpha * (alpha / alpha_max) + w_beta * (beta / beta_max)
    gamma = np.clip(gamma, 0, 1)
    return gamma, alpha_max, beta_max

# ======================================================================================================================
def calculate_ssf(population, dimensions, grid_cells=8):
    """
    Calculate the Signature Factor (SSF) based on the density of the population in a grid.
    This metric is the ratio of empty hypercubes to the total number of hypercubes.
    """
    grid_size = grid_cells
    grid = np.zeros((grid_size,) * dimensions)
    for individual in population:
        # Convert each coordinate to an integer index in the grid
        indices = tuple((individual * grid_size).astype(int) % grid_size)
        grid[indices] += 1
    empty_hypercubes = np.sum(grid == 0)
    return float(empty_hypercubes / (grid_size ** dimensions))  # normalized by total cell count

# ======================================================================================================================
def apply_rps_i(population, gamma, best_index=None, bounds=(0,1), print_info=False):
    """
    Apply RPS-I by regenerating a subset of the population based on gamma.
    The number of individuals to regenerate is:
       N_regen = floor((1 - gamma) * (P - 1))
    The best solution (best_index) is preserved.
    """
    N = len(population)
    num_to_regenerate = int(np.floor((1 - gamma) * (N - 1)))

    # Exclude the best solution
    indices = np.arange(N)
    if best_index is not None:
        indices = np.delete(indices, best_index)

    if num_to_regenerate > 0 and len(indices) > 0:
        regen_indices = np.random.choice(indices, min(num_to_regenerate, len(indices)), replace=False)
        if print_info:
            print(f"    Regenerating individuals at indices: {regen_indices}")
        for i in regen_indices:
            population[i] = np.random.uniform(bounds[0], bounds[1], population.shape[1])

    return population

# ======================================================================================================================
# Standard GWO
# ======================================================================================================================
def standard_gwo(pop_size, dimensions, max_generations=100, bounds=(0,1)):
    """
    Standard Grey Wolf Optimizer (GWO):
      - Initialize population
      - Identify alpha, beta, delta wolves
      - Update each wolf based on alpha, beta, delta
      - 'a' linearly decreases from 2 to 0
      - Compute SSF each iteration
    """
    # 1) Initialize
    population = initialize_population(pop_size, dimensions, bounds)

    # Evaluate initial population
    scores = np.array([objective_function(ind) for ind in population])

    # Identify best three solutions (alpha, beta, delta)
    alpha_index = np.argmin(scores)  # best
    alpha_score = scores[alpha_index]
    alpha_pos = population[alpha_index].copy()

    # For naming clarity, let's define a function to rank the wolves
    def update_alpha_beta_delta(pop, scr):
        # Sort indices by ascending score
        sorted_idx = np.argsort(scr)
        return sorted_idx[0], sorted_idx[1], sorted_idx[2]  # alpha, beta, delta indices

    beta_index, delta_index = None, None
    # 2) Main loop
    ssf_values = []

    for gen in range(max_generations):
        # Update alpha, beta, delta
        alpha_idx, beta_idx, delta_idx = update_alpha_beta_delta(population, scores)
        alpha_score = scores[alpha_idx]
        beta_score  = scores[beta_idx]
        delta_score = scores[delta_idx]

        alpha_pos = population[alpha_idx].copy()
        beta_pos  = population[beta_idx].copy()
        delta_pos = population[delta_idx].copy()

        # Measure SSF
        ssf_values.append(calculate_ssf(population, dimensions))

        # Linearly decrease parameter a from 2 -> 0
        a = 2.0 - (2.0 * gen / (max_generations - 1))

        # GWO position update
        for i in range(pop_size):
            r1, r2 = np.random.rand(), np.random.rand()
            A1 = 2.0 * a * r1 - a
            C1 = 2.0 * r2
            D_alpha = np.abs(C1 * alpha_pos - population[i])
            X1 = alpha_pos - A1 * D_alpha

            r1, r2 = np.random.rand(), np.random.rand()
            A2 = 2.0 * a * r1 - a
            C2 = 2.0 * r2
            D_beta = np.abs(C2 * beta_pos - population[i])
            X2 = beta_pos - A2 * D_beta

            r1, r2 = np.random.rand(), np.random.rand()
            A3 = 2.0 * a * r1 - a
            C3 = 2.0 * r2
            D_delta = np.abs(C3 * delta_pos - population[i])
            X3 = delta_pos - A3 * D_delta

            new_position = (X1 + X2 + X3) / 3.0
            # Clip to bounds
            new_position = np.clip(new_position, bounds[0], bounds[1])
            population[i] = new_position

        # Evaluate updated population
        scores = np.array([objective_function(ind) for ind in population])

    return ssf_values

# ======================================================================================================================
# RPS-I-GWO
# ======================================================================================================================
def rps_i_gwo(pop_size, dimensions, max_generations=100, bounds=(0,1)):
    """
    Grey Wolf Optimizer with RPS-I applied each generation:
      - Compute alpha (population diversity), beta (improvement rate), gamma
      - Reinitialize part of the population based on gamma
      - Then perform the standard GWO update
    """
    # 1) Initialize
    population = initialize_population(pop_size, dimensions, bounds)
    scores = np.array([objective_function(ind) for ind in population])

    # Identify best solution
    alpha_index = np.argmin(scores)
    alpha_score = scores[alpha_index]

    # For RPS-I metrics
    alpha_max, beta_max = 1e-6, 1e-6
    fitness_best_prev = alpha_score

    # Function to get alpha, beta, delta
    def get_alpha_beta_delta(pop, scr):
        sorted_idx = np.argsort(scr)
        return sorted_idx[0], sorted_idx[1], sorted_idx[2]

    ssf_values = []

    # 2) Main loop
    for gen in range(max_generations):
        # Identify alpha, beta, delta
        alpha_idx, beta_idx, delta_idx = get_alpha_beta_delta(population, scores)
        alpha_score = scores[alpha_idx]
        beta_score_val = scores[beta_idx]
        delta_score_val = scores[delta_idx]

        # Compute alpha (diversity), beta (improvement rate), gamma
        diversity = calculate_population_diversity(population)
        improvement = calculate_improvement_rate(fitness_best_prev, alpha_score)
        gamma, alpha_max, beta_max = calculate_gamma(diversity, alpha_max, improvement, beta_max)

        # Apply RPS-I
        num_to_regen = int(np.floor((1 - gamma) * (len(population) - 1)))
        print("------------------------------------------------------------------------------------------------------------------")
        print(f"Generation {gen}: gamma = {gamma:.4f}, reinitialize count = {num_to_regen}")
        population = apply_rps_i(population, gamma, best_index=alpha_idx, bounds=bounds, print_info=True)

        # Measure SSF after reinit
        ssf_after_reinit = calculate_ssf(population, dimensions)
        print(f"    SSF : {ssf_after_reinit:.4f}")
        ssf_values.append(ssf_after_reinit)

        # Now do the standard GWO update
        # Evaluate again if population changed
        scores = np.array([objective_function(ind) for ind in population])
        alpha_idx, beta_idx, delta_idx = get_alpha_beta_delta(population, scores)
        alpha_pos = population[alpha_idx].copy()
        beta_pos  = population[beta_idx].copy()
        delta_pos = population[delta_idx].copy()

        # linearly reduce a from 2 -> 0
        a = 2.0 - (2.0 * gen / (max_generations - 1))

        pop_size_ = len(population)
        for i in range(pop_size_):
            r1, r2 = np.random.rand(), np.random.rand()
            A1 = 2.0 * a * r1 - a
            C1 = 2.0 * r2
            D_alpha = np.abs(C1 * alpha_pos - population[i])
            X1 = alpha_pos - A1 * D_alpha

            r1, r2 = np.random.rand(), np.random.rand()
            A2 = 2.0 * a * r1 - a
            C2 = 2.0 * r2
            D_beta = np.abs(C2 * beta_pos - population[i])
            X2 = beta_pos - A2 * D_beta

            r1, r2 = np.random.rand(), np.random.rand()
            A3 = 2.0 * a * r1 - a
            C3 = 2.0 * r2
            D_delta = np.abs(C3 * delta_pos - population[i])
            X3 = delta_pos - A3 * D_delta

            new_position = (X1 + X2 + X3) / 3.0
            new_position = np.clip(new_position, bounds[0], bounds[1])
            population[i] = new_position

        # Evaluate population after GWO update
        scores = np.array([objective_function(ind) for ind in population])

        # Update fitness_best_prev for next generation
        alpha_idx = np.argmin(scores)
        fitness_best_prev = scores[alpha_idx]

    return ssf_values

# ======================================================================================================================
# Main Execution
# ======================================================================================================================
if __name__ == "__main__":
    # Parameters
    dimensions = 3         # Dimensionality of the problem ([0,1]^3)
    pop_size = 512         # Population size
    max_generations = 100  # Number of generations
    bounds = (0,1)

    # Run standard GWO
    ssf_values_gwo = standard_gwo(pop_size, dimensions, max_generations, bounds)

    # Run RPS-I-GWO
    ssf_values_rps_gwo = rps_i_gwo(pop_size, dimensions, max_generations, bounds)

    print("------------------------------------------------------------------------------------------------------------------")

    # Print SSF comparison for selected iterations
    print("SSF values for particular iterations of Standard GWO:")
    print(f"Iteration 0:  {ssf_values_gwo[0]:.4f}")
    print(f"Iteration 24: {ssf_values_gwo[24]:.4f}")
    print(f"Iteration 49: {ssf_values_gwo[49]:.4f}")
    print(f"Iteration 74: {ssf_values_gwo[74]:.4f}")
    print(f"Iteration 99: {ssf_values_gwo[99]:.4f}")

    print("------------------------------------------------------------------------------------------------------------------")

    print("\nSSF values for particular iterations of RPS-I GWO:")
    print(f"Iteration 0:  {ssf_values_rps_gwo[0]:.4f}")
    print(f"Iteration 24: {ssf_values_rps_gwo[24]:.4f}")
    print(f"Iteration 49: {ssf_values_rps_gwo[49]:.4f}")
    print(f"Iteration 74: {ssf_values_rps_gwo[74]:.4f}")
    print(f"Iteration 99: {ssf_values_rps_gwo[99]:.4f}")

    # Plot the results
    plt.figure(figsize=(10, 6))
    plt.plot(ssf_values_gwo, label="GWO", marker='o', markersize=4, linewidth=2)
    plt.plot(ssf_values_rps_gwo, label="RPS-I-GWO", marker='s', markersize=4, linewidth=2)
    plt.legend(fontsize=16)
    plt.xlim(0, max_generations)
    plt.ylim(0.3, 1)
    plt.xlabel("Iteration", fontsize=16)
    plt.ylabel("Signature Factor (η)", fontsize=16)
    plt.grid(True)

    # Add a thick border around the plot area
    border_thickness = 5
    plt.gca().add_patch(
        patches.Rectangle(
            (0, 0), 1, 1, transform=plt.gca().transAxes,
            linewidth=border_thickness, edgecolor='black', facecolor='none'
        )
    )

    plt.show()
    print("------------------------------------------------------------------------------------------------------------------")
# ======================================================================================================================
# ======================================================================================================================
