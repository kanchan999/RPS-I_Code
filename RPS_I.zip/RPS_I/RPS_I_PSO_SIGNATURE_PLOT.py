# Code for visualization (signature) of population in PSO and RPS-I-PSO (Figure 6)
# Paper title: Regenerative Population Strategy-I: A Dynamic Methodology to Mitigate
#              Structural Bias in Metaheuristic Algorithms)
# Author: Kanchan Rajwar
# For assistance, contact: kanchanrajwar1519@gmail.com
#=======================================================================================================================
#=======================================================================================================================
import numpy as np
import matplotlib.pyplot as plt


# ---------------------------
# Function and Parameter Setup
# ---------------------------
def random_function(x, y):
    return np.random.rand()  # Returns a random value in [0,1]


# PSO parameters
num_particles = 10000  # Number of particles in the swarm
num_iterations = 10  # Number of iterations (generations)

# PSO coefficients
c1 = 2  # Cognitive coefficient
c2 = 2  # Social coefficient

# Inertia weight will be linearly reduced from 0.9 to 0.1
w_max = 0.9
w_min = 0.1

# Grid parameters for visualization (dividing [0,1]^2 into a 100x100 grid)
grid_size = 100
cell_size = 1 / grid_size  # Size of each cell in the grid


# ---------------------------
# Run PSO and Capture Population Snapshots
# ---------------------------
def run_pso_and_capture_population(replace_random=False):
    """
    Run PSO and capture the swarm's positions at each iteration.
    When replace_random is False, a standard PSO is used.
    When replace_random is True, the RPS-I mechanism is applied:
      - Compute population diversity (α) and improvement rate (β)
      - Calculate combined score γ (normalized using running maximums)
      - Determine the number of particles to reinitialize as:
            N_regen = floor((1 - γ) * (num_particles - 1))
        (the global best is preserved)
    The inertia weight is reduced linearly from 0.9 to 0.1.
    """
    # Initialize particle positions and velocities
    positions = np.random.rand(num_particles, 2)  # Positions in [0,1]^2
    velocities = np.random.rand(num_particles, 2) * 0.1  # Small initial velocities
    personal_best_positions = positions.copy()
    personal_best_scores = np.array([random_function(*p) for p in positions])
    global_best_index = np.argmin(personal_best_scores)
    global_best_position = personal_best_positions[global_best_index].copy()
    global_best_score = min(personal_best_scores)

    # For RPS-I: initialize running maximums and previous global best
    if replace_random:
        alpha_max = 1e-6
        beta_max = 1e-6
        prev_global_best = global_best_score

    # Dictionary to store snapshots of positions at each iteration
    population_snapshots = {0: positions.copy()}
    empty_cells_per_iteration = []  # (Optional) Tracking empty grid cells

    # PSO loop
    for iteration in range(num_iterations):
        # Compute inertia weight linearly reduced from 0.9 to 0.1
        w_current = w_max - (w_max - w_min) * iteration / (num_iterations - 1)

        # Create a grid occupancy map (for visualization/SSF, if desired)
        occupied_cells = np.zeros((grid_size, grid_size), dtype=bool)
        for pos in positions:
            grid_x = int(pos[0] // cell_size)
            grid_y = int(pos[1] // cell_size)
            occupied_cells[grid_x, grid_y] = True
        num_empty_cells = np.sum(~occupied_cells)
        empty_cells_per_iteration.append(num_empty_cells)

        # Update particles using PSO operators
        for i in range(num_particles):
            score = random_function(*positions[i])
            # Update personal best if improved
            if score < personal_best_scores[i]:
                personal_best_scores[i] = score
                personal_best_positions[i] = positions[i].copy()
            # Update global best if improved
            if score < global_best_score:
                global_best_score = score
                global_best_index = i
                global_best_position = positions[i].copy()
            # Update velocity and position using PSO equations with linear inertia
            inertia = w_current * velocities[i]
            cognitive = c1 * np.random.rand() * (personal_best_positions[i] - positions[i])
            social = c2 * np.random.rand() * (global_best_position - positions[i])
            velocities[i] = inertia + cognitive + social
            positions[i] = np.clip(positions[i] + velocities[i], 0, 1)

        # Apply RPS-I regeneration if enabled
        if replace_random:
            # Calculate population diversity (α)
            mean_position = np.mean(positions, axis=0)
            alpha = np.sum(np.linalg.norm(positions - mean_position, axis=1))
            alpha_max = max(alpha_max, alpha)
            # Calculate improvement rate (β)
            beta = (prev_global_best - global_best_score) / (global_best_score + 1e-9)
            beta_max = max(beta_max, beta)
            # Combined score γ (weighted equally)
            gamma = 0.5 * (alpha / alpha_max) + 0.5 * (beta / beta_max)
            gamma = np.clip(gamma, 0, 1)
            # Determine number of particles to reinitialize (excluding the global best)
            num_to_regenerate = int(np.floor((1 - gamma) * (num_particles - 1)))
            print(f"Iteration {iteration}: gamma = {gamma:.4f}, reinitialize count = {num_to_regenerate}")
            # Exclude the global best index from regeneration
            indices = np.arange(num_particles)
            indices = np.delete(indices, global_best_index)
            if num_to_regenerate > 0 and len(indices) > 0:
                regen_indices = np.random.choice(indices, min(num_to_regenerate, len(indices)), replace=False)
                for idx in regen_indices:
                    positions[idx] = np.random.rand(2)  # New random position in [0,1]^2
                    velocities[idx] = np.random.rand(2) * 0.1  # New small initial velocity
            prev_global_best = global_best_score  # Update for the next iteration

        # Capture positions for this iteration (after PSO update and regeneration, if any)
        population_snapshots[iteration + 1] = positions.copy()

    return empty_cells_per_iteration, population_snapshots


# ---------------------------
# Run PSO for Both Versions
# ---------------------------
# Run standard PSO (without RPS-I)
_, population_snapshots_original = run_pso_and_capture_population(replace_random=False)
# Run RPS-I PSO (with proper regeneration using linear inertia weight reduction)
_, population_snapshots_replacement = run_pso_and_capture_population(replace_random=True)

# ---------------------------
# Visualization (Same as Your Provided Code)
# ---------------------------
for iteration in range(num_iterations + 1):
    fig, axs = plt.subplots(1, 2, figsize=(12, 6))

    # Original PSO visualization
    axs[0].scatter(population_snapshots_original[iteration][:, 0],
                   population_snapshots_original[iteration][:, 1],
                   c="black", s=10, alpha=1.0)
    axs[0].set_title("PSO - Generation: {}".format(iteration), fontsize=20)
    axs[0].set_xlim(0, 1)
    axs[0].set_ylim(0, 1)
    axs[0].set_xlabel("X", fontsize=15)
    axs[0].set_ylabel("Y", fontsize=15)
    axs[0].tick_params(axis='both', labelsize=15)
    for i in range(1, grid_size):
        axs[0].axhline(i * cell_size, color='gray', linestyle='-', linewidth=0.5)
        axs[0].axvline(i * cell_size, color='gray', linestyle='-', linewidth=0.5)
    axs[0].grid(False)

    # RPS-I PSO visualization
    axs[1].scatter(population_snapshots_replacement[iteration][:, 0],
                   population_snapshots_replacement[iteration][:, 1],
                   c="black", s=10, alpha=1.0)
    axs[1].set_title("RPS-I-PSO - Generation: {}".format(iteration), fontsize=20)
    axs[1].set_xlim(0, 1)
    axs[1].set_ylim(0, 1)
    axs[1].set_xlabel("X", fontsize=15)
    axs[1].set_ylabel("Y", fontsize=15)
    axs[1].tick_params(axis='both', labelsize=15)
    for i in range(1, grid_size):
        axs[1].axhline(i * cell_size, color='gray', linestyle='-', linewidth=0.5)
        axs[1].axvline(i * cell_size, color='gray', linestyle='-', linewidth=0.5)
    axs[1].grid(False)

    plt.tight_layout()
    plt.show()
